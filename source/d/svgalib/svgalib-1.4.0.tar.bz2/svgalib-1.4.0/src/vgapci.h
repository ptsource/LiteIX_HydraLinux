extern int __svgalib_pci_find_vendor_vga(unsigned int vendor, unsigned long *conf);
extern int __svgalib_use_procpci;
