fptools.o: fptools.c
