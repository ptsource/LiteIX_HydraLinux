uucheck.o: uucheck.c
