uuscan.o: uuscan.c
