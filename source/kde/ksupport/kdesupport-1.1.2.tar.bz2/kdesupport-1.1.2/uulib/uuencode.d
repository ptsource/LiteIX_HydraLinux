uuencode.o: uuencode.c
