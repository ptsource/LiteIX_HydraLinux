uustring.o: uustring.c
