# $XConsortium: Xservers.fs,v 1.3 93/09/28 14:30:31 gildea Exp $
# $Id: Xservers.fs,v 1.2 1998/09/30 21:20:29 bieker Exp $
#
# Xservers file, fileserver prototype (any machine without a display)
#
# Put X terminals which don't support XDMCP in this file; you will
# want to leave those terminals on and connected to the network, else
# xdm will have a tougher time managing them.
#
# Each line should look like:
#
#	XterminalName:0 foreign
