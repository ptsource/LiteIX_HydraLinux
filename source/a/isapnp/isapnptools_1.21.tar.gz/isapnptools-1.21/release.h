/* release.h */
#define ISAPNPTOOLSVER "isapnptools-1.21"

#ifdef _AXP_
#define RELEASE_AXP " -D_AXP_"
#else
#define RELEASE_AXP
#endif /* _AXP_ */

#ifdef REALTIME
#define RELEASE_REALTIME " -DREALTIME"
#else
#define RELEASE_REALTIME
#endif /* REALTIME */

#ifdef NEEDSETSCHEDULER
#define RELEASE_NEEDSCH " -DNEEDSETSCHEDULER"
#else
#define RELEASE_NEEDSCH
#endif /* NEEDSETSCHEDULER */

#ifdef NEEDNANOSLEEP
#define RELEASE_NEEDNANO " -DNEEDNANOSLEEP"
#else
#define RELEASE_NEEDNANO
#endif /* NEEDNANOSLEEP */

#ifdef ABORT_ONRESERR
#define RELEASE_NEEDABORT " -DABORT_ONRESERR"
#else
#define RELEASE_NEEDABORT
#endif /* ABORT_ONRESERR */

#define ISAPNPTOOLSCOMPILERFLAGS RELEASE_AXP RELEASE_REALTIME \
                     RELEASE_NEEDSCH RELEASE_NEEDNANO RELEASE_NEEDABORT

extern char libtoolsver[];
extern char libcompilerflags[];

/* End of release.h */
