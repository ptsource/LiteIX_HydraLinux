#include "release.h"

char libtoolsver[] = ISAPNPTOOLSVER;
char libcompilerflags[] = ISAPNPTOOLSCOMPILERFLAGS;
