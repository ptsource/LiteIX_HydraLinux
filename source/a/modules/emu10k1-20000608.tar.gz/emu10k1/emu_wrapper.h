#ifndef __EMU_WRAPPER_H
#define __EMU_WRAPPER_H

#include <linux/wrapper.h>

#define UP_INODE_SEM(a)
#define DOWN_INODE_SEM(a)

#define GET_INODE_STRUCT()

#define PCI_SET_DMA_MASK(pdev,mask)        (((pdev)->dma_mask) = (mask))

#define compat_request_region request_region

#ifndef PCI_GET_DRIVER_DATA
  #define PCI_GET_DRIVER_DATA(pdev)             ((pdev)->driver_data)
  #define PCI_SET_DRIVER_DATA(pdev,data)        (((pdev)->driver_data) = (data))
#endif /* PCI_GET_DRIVER_DATA */

#endif
