/*     
 **********************************************************************
 *     mmwave.h
 *     Copyright 1999, 2000 Creative Labs, Inc. 
 * 
 ********************************************************************** 
 * 
 *     Date                 Author          Summary of changes 
 *     ----                 ------          ------------------ 
 *     October 20, 1999     Bertrand Lee    base code release 
 * 
 ********************************************************************** 
 * 
 *     This program is free software; you can redistribute it and/or 
 *     modify it under the terms of the GNU General Public License as 
 *     published by the Free Software Foundation; either version 2 of 
 *     the License, or (at your option) any later version. 
 * 
 *     This program is distributed in the hope that it will be useful, 
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of 
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 *     GNU General Public License for more details. 
 * 
 *     You should have received a copy of the GNU General Public 
 *     License along with this program; if not, write to the Free 
 *     Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, 
 *     USA. 
 * 
 ********************************************************************** 
 */

#ifndef _MMWAVE_H
#define _MMWAVE_H

/* Enumeration for SetControl */
enum
{
    WAVESTARTLOOP = 0x10,
    WAVEENDLOOP,
    WAVECURPOS,
    WAVESTOPPOSITION,
    WAVEWRITEPOINTER,
    WAVESETSTOPONLOOP,

    WAVEOBJVOLUME = 0x20,
    WAVEINSTANCEVOLUME,
    WAVEOBJREVERB,
    WAVEINSTANCEREVERB,
    WAVEOBJCHORUS,
    WAVEINSTANCECHORUS,
    WAVEOBJMUTE,
    WAVEVOLFACTOR,
    WAVEREVERBFACTOR,
    WAVECHORUSFACTOR,
    WAVEINSTANCEPITCHOFFSET,
    WAVEINSTANCESEND,

    WAVESYNCHSETUP = 0x30,
    WAVESYNCHSTART,
    WAVESETFREQUENCY,
    WAVESETSTARTFLAG,
    WAVEQUERYACTIVEINST,
    WAVEINSTANCEFILTERQ,
    WAVEINSTANCEFILTERCUTOFF,
    WAVEINSTANCEFORMAT,


    WAVEPROPERTYSETGET = 0x200,
    WAVEPROPERTYSETSET,
    WAVEPROPERTYSETQUERYSUPPORT,

    WAVEGET3DBUFFERPROPERTYSETIFACE = 0x250,
    WAVEGET3DLISTENERPROPERTYSETIFACE,
    WAVENUMFREE3DBUFFERS

};

#endif /* _MMWAVE_H */
