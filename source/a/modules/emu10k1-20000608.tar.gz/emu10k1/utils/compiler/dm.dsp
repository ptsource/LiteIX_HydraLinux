int i, j, k, l;

RESET();

for (j = 0; j < 2; j++) {

	OP(4, GP(0), C_0, FX(j), C_4);
	OP(4, GP(1), C_0, FX(j + 2), C_4);

	for (i = 0; i < 6; i++) {
		k = i * 16 + j;
		OP(0, GP(2), C_0, GP(16 + k), GP(0));
		OP(0, GP(2), GP(2), GP(18 + k), GP(1));
		OP(0, GP(2), GP(2), GP(20 + k), IN(0, j));
		OP(0, GP(2), GP(2), GP(22 + k), IN(1, j));
		OP(0, GP(2), GP(2), GP(24 + k), IN(2, j));
		OP(0, GP(2), GP(2), GP(26 + k), IN(3, j));
		OP(0, GP(2), GP(2), GP(28 + k), IN(4, j));
		OP(0, GP(2), GP(2), GP(30 + k), IN(5, j));

		k = 0x90 + i * 8 + j * 4;
		OP(0, C_0, C_0, GP(2), GP(0x70 + j));
		OP(7, GP(k + 1), GP(k), GP(k + 1), GP(0x74 + j));
		OP(7, GP(k), GP(2), GP(k), GP(0x72 + j));
		OP(7, GP(k + 3), GP(k + 2), GP(k + 3), GP(0x78 + j));
		OP(0, GP(k + 2), ACCUM, GP(k + 2), GP(0x76 + j));
		OP(6, GP(k + 2), GP(k + 2), GP(k + 2), C_0);

		l = 0xc0 + i * 8 + j * 4;
		OP(0, C_0, C_0, GP(k + 2), GP(0x80 + j));
		OP(7, GP(l + 1), GP(l), GP(l + 1), GP(0x84 + j));
		OP(7, GP(l), GP(k + 2), GP(l), GP(0x82 + j));
		OP(7, GP(l + 3), GP(l + 2), GP(l + 3), GP(0x88 + j));
		OP(0, GP(l + 2), ACCUM, GP(l + 2), GP(0x86 + j));
		OP(4, GP(l + 2), C_0, GP(l + 2), C_16);
		OP(6, OUT(i, j), GP(l + 2), C_0, C_0);
	}
}
