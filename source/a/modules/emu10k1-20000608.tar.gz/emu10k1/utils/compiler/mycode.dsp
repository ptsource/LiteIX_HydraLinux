#define b gpr(1)     /* prefered way of symbol definition */

int a;
a=gpr(0);	     /* this behaves like a pointer, a is not the value of gpr(0) but it's address ... */

DECLARE_GPR_DYNAMIC(a);
DECLARE_GPR_DYNAMIC(gpr(2) + 3);   /* like wise this is pointer arithmetics, gpr(5) is being defined as dynamic */
DECLARE_GPR_STATIC(b);
DECLARE_GPR_INPUT(gpr(2));

acc3(gpr(0), in(0), in(2), in(4));
acc3(gpr(1), in(1), in(3), in(5));
acc3(a, gpr(0), in(6), in(8));
acc3(b, b, in(7), in(9));
acc3(a, gpr(0), in(10), in(12));
acc3(gpr(2), gpr(2), in(11), in(13));

acc3(REAR_L, in(6), C_0, C_0);
acc3(REAR_R, in(7), C_0, C_0);

