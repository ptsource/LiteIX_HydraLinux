#ifndef TYPES_H
#define TYPES_H

#define u8 unsigned char
#define u16 unsigned short int
#define u32 unsigned int

#endif
