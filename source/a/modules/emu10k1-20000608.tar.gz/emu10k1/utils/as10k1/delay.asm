;;; A simple delay routine
	
	include "emu_constants.asm"	

outl equ $020
outr equ $021
mic  equ $010
		 
level		dc $40000000
feedback	dc $40000000
rsource	ds 1
lsource ds 1	
	
;;; we use external TRAM here so make sure you've enabled
;;; your driver to support it.
	
	orgd	$280
rwrite	ds	1
rread	ds	1
lwrite	ds	1	
lread	ds	1
			
	orgd	$380
drwa  dc  $200000					
drra  dc  $107fff		
	
dlwa dc   $208000
dlra dc   $10ffff
	
				
 	acc3 rsource,C_0,mic,outr

	acc3 lsource,C_0,mic,outl
;;; Right

	
	mac_s  outr,outr,level,rread
	MAC_s  rwrite,rsource,outr,feedback

;;; Left
	
	mac_s   outl,outl,level,lread
	mac_s  lwrite,lsource,outl,feedback	
	
	end
		


