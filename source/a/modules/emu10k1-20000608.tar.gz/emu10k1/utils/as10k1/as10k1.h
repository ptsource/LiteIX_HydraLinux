/***************************************************************************
                          as10k1.h  -  description
                             -------------------
    Date                 : May 25, 2000
    Copyright            : (C) 2000 by Daniel Bertrand
    Email                : d.bertrand@ieee.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/



void asm_open(char *incl);

#define max_depth 3   //max include nesting depth
FILE *dc_fp;
int  symbol_count=0;
int source_line_num=1; 	//this no longer works since adding includes
int dsp_addr=0;
int include_depth=0;


struct parsed_struct parsed[DSP_CODE_SIZE];
struct symbol sym_table[max_num_symbol];

int parse( char line_string[max_line_length]);
void assemble(void);
