
	include "emu_constants.asm"

outl equ $020
outr equ $021
delta dc $3afa691		; controls frequency

		
cosx dc $7fffffff		; amplitude of sinewave 
sinx dc 0	

	
		
	mac_s  sinx,sinx,delta,cosx       
	mac_1s cosx,cosx,delta,sinx 

	macmv  outr,cosx,C_0,C_0
	macmv  outl,cosx,C_0,C_0
	
	end








