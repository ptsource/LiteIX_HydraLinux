;some hardware constants C_[n]<DecimalValue>, 'n' indicates negative value
;		
;these are in 2's complement representation

C_0	equ $040
C_1	equ $041
C_2	equ $042
C_3	equ $043
C_4	equ $044
C_8	equ $045
C_16	equ $046
C_32	equ $047
C_256	equ $048
C_65536 equ $049
C_2^23 	equ $04A
C_2^28	equ $04b
C_2^29	equ $04c  ;;(C_max /4) +1
C_2^30	equ $04d  ;;( C_max / 2 ) + 1 (almost half)	
C_nmax	equ $04e  ;;most negative number
C_max	equ $04f  ;;most positive number	
C_n1	equ $050  ;;-1
C_n2	equ $051  ;;-2
C_n2^30	equ $052  ;;C_nmax /2
	

	end