/***************************************************************************
                          global.h  -  description
                             -------------------
    Date                : May 22 2000
    Copyright            : (C) 2000 by Daniel Bertrand
    Email                : d.bertrand@ieee.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#define max_num_symbol 100 //max number of symbols

#define max_length_symbol 11 // maximum length of a symbol

#define max_line_length 80   //max length of a source code line
#define DSP_CODE_SIZE 1024



struct parsed_struct{
		int source_line;
		int op_number;
		char operand[max_line_length];
		};
						
struct symbol{
		char name[max_length_symbol];
		int value;
		};

			
		


 		
				
