/***************************************************************************
                          parse.h  -  description
                             -------------------
    Date                 : May 23  2000
    Copyright            : (C) 2000 by Daniel Bertrand
    Email                : d.bertrand@ieee.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#define num_ops 17   //number of op code mneumonic and directives

char op_codes[num_ops][9]=
  {
    "MAC_S",
    "MAC_1S",
    "MAC_W",
    "MAC_1W",
    "MACINT_S",
    "MACINT_W",
    "ACC3",
    "MACMV",
    "ANDXOR",
    "TSTNEG",
    "LIMIT",
    "LIMIT_1",
    "LOG",
    "EXP",
    "INTERP",
    "SKIP",
    "NotAnOp"
  };

extern int source_line_num;

void new_symbol( char *equ_name_ptr, int constant);
int op_decode(char *op_name_ptr);
int operand_decode(char *);
void asm_open(char *incl);
void new_dc(char *symbol,char *constant, int addr);

#define max_macro 25

struct macro{
	char name;
	char *ptr;
	};	

struct macro macro_table[max_macro]; 	


