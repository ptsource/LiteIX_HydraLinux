\initial {!}
\entry {\code {!} operator}{91}
\entry {\code {!=} operator}{89}
\entry {\code {!~} operator}{23, 33, 35, 77, 89}
\initial {#}
\entry {\code {#} (comment)}{13}
\entry {\code {#!} (executable scripts)}{12}
\initial {$}
\entry {\code {$} (field operator)}{40}
\initial {&}
\entry {\code {&&} operator}{91}
\initial {-}
\entry {\code {--assign} option}{161}
\entry {\code {--compat} option}{162}
\entry {\code {--copyleft} option}{162}
\entry {\code {--copyright} option}{162}
\entry {\code {--field-separator} option}{161}
\entry {\code {--file} option}{161}
\entry {\code {--help} option}{163}
\entry {\code {--lint} option}{163}
\entry {\code {--lint-old} option}{163}
\entry {\code {--posix} option}{163}
\entry {\code {--source} option}{164}
\entry {\code {--traditional} option}{162}
\entry {\code {--usage} option}{163}
\entry {\code {--version} option}{164}
\entry {\code {-f} option}{11, 161}
\entry {\code {-F} option}{47, 161}
\entry {\code {-v} option}{161}
\entry {\code {-W} option}{162}
\initial {/}
\entry {\file {/dev/fd}}{72}
\entry {\file {/dev/pgrpid}}{73}
\entry {\file {/dev/pid}}{73}
\entry {\file {/dev/ppid}}{73}
\entry {\file {/dev/stderr}}{72}
\entry {\file {/dev/stdin}}{72}
\entry {\file {/dev/stdout}}{72}
\entry {\file {/dev/user}}{73, 192}
\initial {=}
\entry {\code {==} operator}{89}
\initial {{\_}}
\entry {\code {_gr_init}}{199}
\entry {\code {_pw_init}}{194}
\entry {\code {_tm_addup}}{179}
\entry {\code {_tm_isleap}}{178}
\initial {{\tt\char '174}}
\entry {\code {||} operator}{91}
\initial {{\tt\char '176}}
\entry {\code {~} operator}{23, 33, 35, 77, 89}
\initial {{\tt\gtr}}
\entry {\code {>} operator}{89}
\entry {\code {>=} operator}{89}
\initial {{\tt\indexbackslash }}
\entry {\code {{\tt\rawbackslashxx }'} regexp operator}{32}
\entry {\code {{\tt\rawbackslashxx }`} regexp operator}{32}
\entry {\code {{\tt\rawbackslashxx }>} regexp operator}{32}
\entry {\code {{\tt\rawbackslashxx }<} regexp operator}{32}
\entry {\code {{\tt\rawbackslashxx }B} regexp operator}{32}
\entry {\code {{\tt\rawbackslashxx }w} regexp operator}{32}
\entry {\code {{\tt\rawbackslashxx }W} regexp operator}{32}
\entry {\code {{\tt\rawbackslashxx }y} regexp operator}{32}
\initial {{\tt\less}}
\entry {\code {<} operator}{89}
\entry {\code {<=} operator}{89}
\initial {A}
\entry {accessing fields}{40}
\entry {account information}{192, 197}
\entry {acronym}{1}
\entry {action, curly braces}{102}
\entry {action, default}{14}
\entry {action, definition of}{102}
\entry {action, empty}{14}
\entry {action, separating statements}{102}
\entry {adding new features}{295}
\entry {addition}{82}
\entry {Aho, Alfred}{1}
\entry {AI programming, using \code {gawk}}{282}
\entry {\code {alarm.awk}}{229}
\entry {amiga}{291}
\entry {anchors in regexps}{27}
\entry {and operator}{91}
\entry {anonymous \code {ftp}}{279, 293}
\entry {applications of \code {awk}}{19}
\entry {\code {ARGC}}{117}
\entry {\code {ARGIND}}{117, 165}
\entry {argument processing}{186}
\entry {arguments in function call}{93}
\entry {arguments, command line}{161}
\entry {\code {ARGV}}{117, 165}
\entry {arithmetic operators}{82}
\entry {array assignment}{125}
\entry {array reference}{124}
\entry {Array subscripts and \code {IGNORECASE}}{124}
\entry {array subscripts, uninitialized variables}{130}
\entry {arrays}{123}
\entry {arrays, associative}{123}
\entry {arrays, definition of}{123}
\entry {arrays, deleting an element}{128}
\entry {arrays, deleting entire contents}{128}
\entry {arrays, multi-dimensional subscripts}{130}
\entry {arrays, presence of elements}{125}
\entry {arrays, sparse}{124}
\entry {arrays, special \code {for} statement}{127}
\entry {arrays, the \code {in} operator}{125}
\entry {artificial intelligence, using \code {gawk}}{282}
\entry {ASCII}{175}
\entry {\code {assert}}{172}
\entry {\code {assert}, C version}{172}
\entry {assertions}{172}
\entry {assignment operators}{84}
\entry {assignment to fields}{42}
\entry {associative arrays}{123}
\entry {\code {atan2}}{136}
\entry {atari}{289}
\entry {automatic initialization}{16}
\entry {\code {awk} language, POSIX version}{25, 27, 28, 31, 48, 64, 68, 82, 86, 95, 96, 109, 110, 111, 115, 138, 144, 154}
\entry {\code {awk} language, V.4 version}{24, 25, 254}
\entry {\code {AWKPATH} environment variable}{166}
\entry {\code {awksed}}{243}
\initial {B}
\entry {backslash continuation}{17, 214}
\entry {backslash continuation and comments}{18}
\entry {backslash continuation in \code {csh}}{16, 17}
\entry {basic function of \code {awk}}{9}
\entry {\file {BBS-list} file}{7}
\entry {\code {BEGIN} special pattern}{100}
\entry {\code {beginfile}}{186}
\entry {body of a loop}{106}
\entry {book, using this}{5}
\entry {boolean expressions}{91}
\entry {boolean operators}{91}
\entry {\code {break} statement}{109}
\entry {\code {break}, outside of loops}{109}
\entry {Brennan, Michael}{128, 243, 293}
\entry {buffer matching operators}{32}
\entry {buffering output}{146, 148}
\entry {buffering, interactive vs. non-interactive}{147}
\entry {buffering, non-interactive vs. interactive}{147}
\entry {buffers, flushing}{146, 148}
\entry {bugs, known in \code {gawk}}{167}
\entry {built-in functions}{135}
\entry {built-in variables}{115}
\entry {built-in variables, convey information}{117}
\entry {built-in variables, user modifiable}{115}
\initial {C}
\entry {call by reference}{156, 157}
\entry {call by value}{156}
\entry {calling a function}{93, 156}
\entry {case conversion}{143}
\entry {case sensitivity}{33}
\entry {changing contents of a field}{42}
\entry {changing the record separator}{37}
\entry {character classes}{28}
\entry {character encodings}{175}
\entry {character list}{27}
\entry {character list, complemented}{29}
\entry {character sets}{175}
\entry {\code {chr}}{174}
\entry {\code {close}}{74, 146}
\entry {closing input files and pipes}{74}
\entry {closing output files and pipes}{74}
\entry {coding style used in \code {gawk}}{296}
\entry {collating elements}{29}
\entry {collating symbols}{29}
\entry {command line}{161}
\entry {command line formats}{10}
\entry {command line, setting \code {FS} on}{47}
\entry {comments}{13}
\entry {comments and backslash continuation}{18}
\entry {common mistakes}{35, 44, 62, 90}
\entry {\code {comp.lang.awk}}{292}
\entry {comparison expressions}{88}
\entry {comparisons, string vs. regexp}{90}
\entry {compatibility mode}{162, 256}
\entry {complemented character list}{29}
\entry {compound statement}{105}
\entry {computed regular expressions}{35}
\entry {concatenation}{83}
\entry {conditional expression}{92}
\entry {configuring \code {gawk}}{285}
\entry {constants, types of}{77}
\entry {continuation of lines}{17}
\entry {\code {continue} statement}{110}
\entry {\code {continue}, outside of loops}{110}
\entry {control statement}{105}
\entry {conversion of case}{143}
\entry {conversion of strings and numbers}{81}
\entry {conversions, during subscripting}{129}
\entry {converting dates to timestamps}{177}
\entry {\code {CONVFMT}}{81, 115, 129}
\entry {\code {cos}}{136}
\entry {\code {csh}, backslash continuation}{16, 17}
\entry {curly braces}{102}
\entry {\code {custom.h} configuration file}{285}
\entry {\code {cut} utility}{205}
\entry {\code {cut.awk}}{206}
\initial {D}
\entry {d.c., see ``dark corner''}{6}
\entry {dark corner}{6, 26, 39, 47, 48, 51, 55, 59, 64, 66, 67, 78, 80, 81, 88, 101, 109, 110, 113, 118, 119, 130, 139, 161, 165}
\entry {data-driven languages}{9}
\entry {dates, converting to timestamps}{177}
\entry {decrement operators}{87}
\entry {default action}{14}
\entry {default pattern}{14}
\entry {defining functions}{153}
\entry {Deifik, Scott}{4, 293}
\entry {\code {delete} statement}{128}
\entry {deleting elements of arrays}{128}
\entry {deleting entire arrays}{128}
\entry {deprecated features}{167}
\entry {deprecated options}{167}
\entry {differences between \code {gawk} and \code {awk}}{33, 39, 46, 54, 59, 71, 72, 75, 77, 78, 83, 93, 102, 112, 121, 128, 135, 139, 142, 166}
\entry {directory search}{166}
\entry {division}{82}
\entry {documenting \code {awk} programs}{13, 202}
\entry {\code {dupword.awk}}{228}
\entry {dynamic regular expressions}{35}
\initial {E}
\entry {EBCDIC}{175}
\entry {\code {egrep}}{10, 28}
\entry {\code {egrep} utility}{210}
\entry {\code {egrep.awk}}{211}
\entry {element assignment}{125}
\entry {element of array}{124}
\entry {empty action}{14}
\entry {empty pattern}{102}
\entry {empty program}{161}
\entry {empty string}{39, 46, 81, 88}
\entry {\code {END} special pattern}{100}
\entry {\code {endfile}}{186}
\entry {\code {endgrent}}{201}
\entry {\code {endpwent}}{196}
\entry {\code {ENVIRON}}{118}
\entry {environment variable, \code {AWKPATH}}{166}
\entry {environment variable, \code {POSIXLY_CORRECT}}{164}
\entry {equivalence classes}{29}
\entry {\code {ERRNO}}{54, 75, 118}
\entry {errors, common}{35, 44, 62, 90}
\entry {escape processing, \code {sub} et. al.}{143}
\entry {escape sequence notation}{24}
\entry {evaluation, order of}{135}
\entry {examining fields}{40}
\entry {executable scripts}{12}
\entry {\code {exit} statement}{112}
\entry {\code {exp}}{136}
\entry {explicit input}{53}
\entry {exponentiation}{82}
\entry {expression}{77}
\entry {expression, assignment}{84}
\entry {expression, boolean}{91}
\entry {expression, comparison}{88}
\entry {expression, conditional}{92}
\entry {expression, matching}{88}
\entry {\code {extract.awk}}{240}
\initial {F}
\entry {features, adding}{295}
\entry {\code {fflush}}{146}
\entry {field operator \code {$}}{40}
\entry {field separator, choice of}{45}
\entry {field separator, \code {FS}}{44}
\entry {field separator, on command line}{47}
\entry {field, changing contents of}{42}
\entry {fields}{40}
\entry {fields, separating}{44}
\entry {\code {FIELDWIDTHS}}{115}
\entry {file descriptors}{72}
\entry {file, \code {awk} program}{11}
\entry {\code {FILENAME}}{37, 59, 118}
\entry {\code {FILENAME}, being set by \code {getline}}{59}
\entry {Fish, Fred}{293}
\entry {flushing buffers}{146, 148}
\entry {\code {FNR}}{40, 118}
\entry {\code {for (x in \dots {})}}{127}
\entry {\code {for} statement}{107}
\entry {format specifier}{65}
\entry {format string}{65}
\entry {format, numeric output}{64}
\entry {formatted output}{64}
\entry {formatted timestamps}{183}
\entry {Free Software Foundation}{1, 279}
\entry {FreeBSD}{2}
\entry {Friedl, Jeffrey}{4}
\entry {\code {FS}}{44, 115}
\entry {\code {ftp}, anonymous}{279, 293}
\entry {function call}{93, 156}
\entry {function definition}{153}
\entry {function, recursive}{154}
\entry {functions, undefined}{157}
\entry {functions, user-defined}{153}
\initial {G}
\entry {\code {gawk} coding style}{296}
\entry {\code {gensub}}{141}
\entry {\code {getgrent}}{201}
\entry {\code {getgrent}, C version}{197}
\entry {\code {getgrgid}}{201}
\entry {\code {getgrnam}}{200}
\entry {\code {getgruser}}{201}
\entry {\code {getline}}{53}
\entry {\code {getline}, return values}{54}
\entry {\code {getline}, setting \code {FILENAME}}{59}
\entry {\code {getopt}}{189}
\entry {\code {getopt}, C version}{186}
\entry {\code {getpwent}}{196}
\entry {\code {getpwent}, C version}{192}
\entry {\code {getpwnam}}{195}
\entry {\code {getpwuid}}{196}
\entry {\code {gettimeofday}}{183}
\entry {getting \code {gawk}}{279}
\entry {GNU Project}{2}
\entry {\code {grcat} program}{197}
\entry {\code {grcat.c}}{197}
\entry {group file}{197}
\entry {group information}{197}
\entry {\code {gsub}}{141}
\entry {\code {gsub}, third argument of}{141}
\initial {H}
\entry {Hankerson, Darrel}{4, 293}
\entry {historical features}{47, 109, 110, 138, 277}
\entry {history of \code {awk}}{1}
\entry {\code {histsort.awk}}{238}
\entry {how \code {awk} works}{14}
\entry {Hughes, Phil}{4}
\initial {I}
\entry {I/O from \code {BEGIN} and \code {END}}{102}
\entry {\code {id} utility}{215}
\entry {\code {id.awk}}{215}
\entry {\code {if}-\code {else} statement}{105}
\entry {\code {igawk.sh}}{246}
\entry {\code {IGNORECASE}}{33, 116, 124}
\entry {\code {IGNORECASE} and array subscripts}{124}
\entry {ignoring case}{33}
\entry {implementation limits}{59, 71}
\entry {\code {in} operator}{89}
\entry {increment operators}{87}
\entry {\code {index}}{137}
\entry {initialization, automatic}{16}
\entry {input}{37}
\entry {input file, sample}{7}
\entry {input files, skipping}{170}
\entry {input pipeline}{57}
\entry {input redirection}{56}
\entry {input, explicit}{53}
\entry {input, \code {getline} command}{53}
\entry {input, multiple line records}{51}
\entry {input, standard}{11}
\entry {installation, amiga}{291}
\entry {installation, atari}{289}
\entry {installation, MS-DOS and OS/2}{288}
\entry {installation, unix}{284}
\entry {installation, vms}{285}
\entry {\code {int}}{136}
\entry {interaction, \code {awk} and other programs}{146}
\entry {interactive buffering vs. non-interactive}{147}
\entry {interval expressions}{31}
\entry {\file {inventory-shipped} file}{7}
\entry {invocation of \code {gawk}}{161}
\entry {ISO 8601}{151}
\entry {ISO 8859-1}{34, 302}
\entry {ISO Latin-1}{34, 302}
\initial {J}
\entry {Jaegermann, Michal}{4, 293}
\entry {\code {join}}{177}
\initial {K}
\entry {Kernighan, Brian}{1, 4, 83, 255, 293}
\entry {known bugs}{167}
\initial {L}
\entry {\code {labels.awk}}{234}
\entry {language, \code {awk}}{5}
\entry {language, data-driven}{9}
\entry {language, procedural}{9}
\entry {leftmost longest match}{34, 51}
\entry {\code {length}}{138}
\entry {limitations}{59, 71}
\entry {line break}{17}
\entry {line continuation}{17, 63, 92, 93}
\entry {Linux}{2, 290}
\entry {locale, definition of}{150}
\entry {\code {log}}{136}
\entry {logical false}{88}
\entry {logical operations}{91}
\entry {logical true}{88}
\entry {login information}{192}
\entry {long options}{161}
\entry {loop}{106}
\entry {loops, exiting}{109}
\entry {lvalue}{84}
\initial {M}
\entry {mark parity}{175}
\entry {\code {match}}{138}
\entry {matching ranges of lines}{99}
\entry {matching, leftmost longest}{34, 51}
\entry {\code {mawk}}{293}
\entry {merging strings}{176}
\entry {metacharacters}{26}
\entry {mistakes, common}{35, 44, 62, 90}
\entry {\code {mktime}}{180}
\entry {modifiers (in format specifiers)}{66}
\entry {multi-dimensional subscripts}{130}
\entry {multiple line records}{51}
\entry {multiple passes over data}{166}
\entry {multiple statements on one line}{18}
\entry {multiplication}{82}
\initial {N}
\entry {names, use of}{153}
\entry {namespace issues in \code {awk}}{202}
\entry {namespaces}{153}
\entry {NetBSD}{2}
\entry {new \code {awk}}{1}
\entry {new \code {awk} vs. old \code {awk}}{9}
\entry {newline}{17}
\entry {\code {next file} statement}{112}
\entry {\code {next} statement}{111}
\entry {\code {next}, inside a user-defined function}{111}
\entry {\code {nextfile} function}{170}
\entry {\code {nextfile} statement}{112}
\entry {\code {NF}}{40, 118}
\entry {non-interactive buffering vs. interactive}{147}
\entry {not operator}{91}
\entry {\code {NR}}{40, 119}
\entry {null string}{46, 81, 88}
\entry {null string, as array subscript}{130}
\entry {number of fields, \code {NF}}{40}
\entry {number of records, \code {NR}, \code {FNR}}{40}
\entry {numbers, used as subscripts}{129}
\entry {numeric character values}{174}
\entry {numeric constant}{77}
\entry {numeric output format}{64}
\entry {numeric string}{88}
\entry {numeric value}{77}
\initial {O}
\entry {obsolete features}{167}
\entry {obsolete options}{167}
\entry {\code {OFMT}}{64, 82, 116}
\entry {\code {OFS}}{63, 116}
\entry {old \code {awk}}{1}
\entry {old \code {awk} vs. new \code {awk}}{9}
\entry {one-liners}{21}
\entry {operations, logical}{91}
\entry {operator precedence}{94}
\entry {operators, arithmetic}{82}
\entry {operators, assignment}{84}
\entry {operators, boolean}{91}
\entry {operators, decrement}{87}
\entry {operators, increment}{87}
\entry {operators, regexp matching}{23}
\entry {operators, relational}{88, 89}
\entry {operators, short-circuit}{91}
\entry {operators, string}{83}
\entry {operators, string-matching}{23}
\entry {options, command line}{161}
\entry {options, long}{161}
\entry {or operator}{91}
\entry {\code {ord}}{174}
\entry {order of evaluation}{135}
\entry {\code {ORS}}{63, 116}
\entry {output}{61}
\entry {output field separator, \code {OFS}}{63}
\entry {output format specifier, \code {OFMT}}{64}
\entry {output record separator, \code {ORS}}{63}
\entry {output redirection}{70}
\entry {output, buffering}{146, 148}
\entry {output, formatted}{64}
\entry {output, piping}{71}
\initial {P}
\entry {passes, multiple}{166}
\entry {password file}{192}
\entry {path, search}{166}
\entry {pattern, \code {BEGIN}}{100}
\entry {pattern, default}{14}
\entry {pattern, definition of}{97}
\entry {pattern, empty}{102}
\entry {pattern, \code {END}}{100}
\entry {pattern, range}{99}
\entry {pattern, regular expressions}{23}
\entry {patterns, types of}{97}
\entry {per file initialization and clean-up}{185}
\entry {PERL}{299}
\entry {pipeline, input}{57}
\entry {pipes for output}{71}
\entry {portability issues}{17, 26, 75, 128, 138, 146, 154, 169}
\entry {porting \code {gawk}}{297}
\entry {POSIX \code {awk}}{25, 27, 28, 31, 48, 64, 68, 82, 86, 95, 96, 109, 110, 111, 115, 138, 144, 154}
\entry {POSIX mode}{163}
\entry {\code {POSIXLY_CORRECT} environment variable}{164}
\entry {precedence}{94}
\entry {precedence, regexp operators}{31}
\entry {\code {print} statement}{61}
\entry {\code {printf} statement, syntax of}{65}
\entry {\code {printf}, format-control characters}{65}
\entry {\code {printf}, modifiers}{66}
\entry {printing}{61}
\entry {procedural languages}{9}
\entry {process information}{73}
\entry {processing arguments}{186}
\entry {program file}{11}
\entry {program, \code {awk}}{5}
\entry {program, definition of}{9}
\entry {program, self contained}{12}
\entry {programs, documenting}{13, 202}
\entry {\code {pwcat} program}{193}
\entry {\code {pwcat.c}}{193}
\initial {Q}
\entry {quotient}{82}
\entry {quoting, shell}{11, 12}
\initial {R}
\entry {Rakitzis, Byron}{238}
\entry {\code {rand}}{136}
\entry {random numbers, seed of}{137}
\entry {range pattern}{99}
\entry {Rankin, Pat}{4, 85, 293}
\entry {reading files}{37}
\entry {reading files, \code {getline} command}{53}
\entry {reading files, multiple line records}{51}
\entry {record separator, \code {RS}}{37}
\entry {record terminator, \code {RT}}{39}
\entry {record, definition of}{37}
\entry {records, multiple line}{51}
\entry {recursive function}{154}
\entry {redirection of input}{56}
\entry {redirection of output}{70}
\entry {reference to array}{124}
\entry {regexp}{23}
\entry {regexp as expression}{91}
\entry {regexp comparison vs. string comparison}{90}
\entry {regexp constant}{24}
\entry {regexp constants, difference between slashes and quotes}{35}
\entry {regexp match/non-match operators}{23, 88}
\entry {regexp matching operators}{23}
\entry {regexp operators}{26}
\entry {regexp operators, GNU specific}{31}
\entry {regexp operators, precedence of}{31}
\entry {regexp, anchors}{27}
\entry {regexp, dynamic}{35}
\entry {regexp, effect of command line options}{32}
\entry {regular expression}{23}
\entry {regular expression metacharacters}{26}
\entry {regular expressions as field separators}{45}
\entry {regular expressions as patterns}{23}
\entry {regular expressions as record separators}{39}
\entry {regular expressions, computed}{35}
\entry {relational operators}{88, 89}
\entry {remainder}{82}
\entry {removing elements of arrays}{128}
\entry {\code {return} statement}{158}
\entry {RFC-1036}{152}
\entry {RFC-822}{152}
\entry {\code {RLENGTH}}{119, 138}
\entry {Robbins, Miriam}{4}
\entry {Rommel, Kai Uwe}{4, 293}
\entry {\code {round}}{173}
\entry {rounding}{173}
\entry {\code {RS}}{37, 116}
\entry {\code {RSTART}}{119, 138}
\entry {\code {RT}}{39, 53, 119}
\entry {rule, definition of}{9}
\entry {running \code {awk} programs}{10}
\entry {running long programs}{11}
\entry {rvalue}{84}
\initial {S}
\entry {sample input file}{7}
\entry {scanning an array}{127}
\entry {script, definition of}{9}
\entry {scripts, executable}{12}
\entry {scripts, shell}{13}
\entry {search path}{166}
\entry {search path, for source files}{166}
\entry {\code {sed} utility}{48, 242, 246}
\entry {seed for random numbers}{137}
\entry {self contained programs}{12}
\entry {shell quoting}{11, 12}
\entry {shell scripts}{13}
\entry {short-circuit operators}{91}
\entry {side effect}{84}
\entry {simple stream editor}{243}
\entry {\code {sin}}{136}
\entry {single character fields}{46}
\entry {single quotes, why needed}{10}
\entry {skipping input files}{170}
\entry {skipping lines between markers}{100}
\entry {sparse arrays}{124}
\entry {\code {split}}{139}
\entry {\code {split} utility}{217}
\entry {\code {split.awk}}{217}
\entry {\code {sprintf}}{140}
\entry {\code {sqrt}}{136}
\entry {\code {srand}}{137}
\entry {Stallman, Richard}{1, 3}
\entry {standard error output}{72}
\entry {standard input}{11, 37, 72}
\entry {standard output}{72}
\entry {statement, compound}{105}
\entry {stream editor}{48}
\entry {stream editor, simple}{243}
\entry {\code {strftime}}{149}
\entry {string comparison vs. regexp comparison}{90}
\entry {string constants}{77}
\entry {string operators}{83}
\entry {string-matching operators}{23}
\entry {\code {sub}}{140}
\entry {\code {sub}, third argument of}{141}
\entry {subscripts in arrays}{130}
\entry {\code {SUBSEP}}{117, 130}
\entry {\code {substr}}{142}
\entry {subtraction}{82}
\entry {\code {system}}{146}
\entry {\code {systime}}{149}
\initial {T}
\entry {Tcl}{203}
\entry {\code {tee} utility}{219}
\entry {\code {tee.awk}}{219}
\entry {terminator, record}{39}
\entry {time of day}{148}
\entry {timestamps}{148}
\entry {timestamps, converting from dates}{177}
\entry {timestamps, formatted}{183}
\entry {\code {tolower}}{143}
\entry {\code {toupper}}{143}
\entry {\code {translate.awk}}{232}
\entry {Trueman, David}{4}
\entry {truth values}{88}
\entry {type conversion}{81}
\entry {types of variables}{84, 88}
\initial {U}
\entry {undefined functions}{157}
\entry {undocumented features}{167}
\entry {uninitialized variables, as array subscripts}{130}
\entry {\code {uniq} utility}{220}
\entry {\code {uniq.awk}}{221}
\entry {use of comments}{13}
\entry {user information}{192}
\entry {user-defined functions}{153}
\entry {user-defined variables}{79}
\entry {uses of \code {awk}}{5}
\entry {using this book}{5}
\initial {V}
\entry {values of characters as numbers}{174}
\entry {variable shadowing}{154}
\entry {variable typing}{88}
\entry {variables, user-defined}{79}
\initial {W}
\entry {Wall, Larry}{299}
\entry {\code {wc} utility}{225}
\entry {\code {wc.awk}}{225}
\entry {Weinberger, Peter}{1}
\entry {when to use \code {awk}}{19}
\entry {\code {while} statement}{106}
\entry {word boundaries, matching}{32}
\entry {word, regexp definition of}{31}
\entry {\code {wordfreq.sh}}{237}
