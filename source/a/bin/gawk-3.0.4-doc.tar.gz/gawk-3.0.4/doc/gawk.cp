\entry{acronym}{1}{acronym}
\entry{history of awk}{1}{history of \code {awk}}
\entry{Aho, Alfred}{1}{Aho, Alfred}
\entry{Weinberger, Peter}{1}{Weinberger, Peter}
\entry{Kernighan, Brian}{1}{Kernighan, Brian}
\entry{old awk}{1}{old \code {awk}}
\entry{new awk}{1}{new \code {awk}}
\entry{Free Software Foundation}{1}{Free Software Foundation}
\entry{Stallman, Richard}{1}{Stallman, Richard}
\entry{GNU Project}{2}{GNU Project}
\entry{Linux}{2}{Linux}
\entry{NetBSD}{2}{NetBSD}
\entry{FreeBSD}{2}{FreeBSD}
\entry{Stallman, Richard}{3}{Stallman, Richard}
\entry{Trueman, David}{4}{Trueman, David}
\entry{Deifik, Scott}{4}{Deifik, Scott}
\entry{Hankerson, Darrel}{4}{Hankerson, Darrel}
\entry{Rommel, Kai Uwe}{4}{Rommel, Kai Uwe}
\entry{Rankin, Pat}{4}{Rankin, Pat}
\entry{Jaegermann, Michal}{4}{Jaegermann, Michal}
\entry{Friedl, Jeffrey}{4}{Friedl, Jeffrey}
\entry{Kernighan, Brian}{4}{Kernighan, Brian}
\entry{Hughes, Phil}{4}{Hughes, Phil}
\entry{Robbins, Miriam}{4}{Robbins, Miriam}
\entry{uses of awk}{5}{uses of \code {awk}}
\entry{book, using this}{5}{book, using this}
\entry{using this book}{5}{using this book}
\entry{language, awk}{5}{language, \code {awk}}
\entry{program, awk}{5}{program, \code {awk}}
\entry{d.c., see ``dark corner''}{6}{d.c., see ``dark corner''}
\entry{dark corner}{6}{dark corner}
\entry{input file, sample}{7}{input file, sample}
\entry{sample input file}{7}{sample input file}
\entry{BBS-list file}{7}{\file {BBS-list} file}
\entry{inventory-shipped file}{7}{\file {inventory-shipped} file}
\entry{script, definition of}{9}{script, definition of}
\entry{rule, definition of}{9}{rule, definition of}
\entry{program, definition of}{9}{program, definition of}
\entry{basic function of awk}{9}{basic function of \code {awk}}
\entry{data-driven languages}{9}{data-driven languages}
\entry{procedural languages}{9}{procedural languages}
\entry{language, data-driven}{9}{language, data-driven}
\entry{language, procedural}{9}{language, procedural}
\entry{program, definition of}{9}{program, definition of}
\entry{rule, definition of}{9}{rule, definition of}
\entry{old awk vs. new awk}{9}{old \code {awk} vs. new \code {awk}}
\entry{new awk vs. old awk}{9}{new \code {awk} vs. old \code {awk}}
\entry{command line formats}{10}{command line formats}
\entry{running awk programs}{10}{running \code {awk} programs}
\entry{single quotes, why needed}{10}{single quotes, why needed}
\entry{egrep}{10}{\code {egrep}}
\entry{standard input}{11}{standard input}
\entry{input, standard}{11}{input, standard}
\entry{quoting, shell}{11}{quoting, shell}
\entry{shell quoting}{11}{shell quoting}
\entry{running long programs}{11}{running long programs}
\entry{-f option}{11}{\code {-f} option}
\entry{program file}{11}{program file}
\entry{file, awk program}{11}{file, \code {awk} program}
\entry{quoting, shell}{12}{quoting, shell}
\entry{shell quoting}{12}{shell quoting}
\entry{executable scripts}{12}{executable scripts}
\entry{scripts, executable}{12}{scripts, executable}
\entry{self contained programs}{12}{self contained programs}
\entry{program, self contained}{12}{program, self contained}
\entry{#! (executable scripts)}{12}{\code {#!} (executable scripts)}
\entry{shell scripts}{13}{shell scripts}
\entry{scripts, shell}{13}{scripts, shell}
\entry{# (comment)}{13}{\code {#} (comment)}
\entry{comments}{13}{comments}
\entry{use of comments}{13}{use of comments}
\entry{documenting awk programs}{13}{documenting \code {awk} programs}
\entry{programs, documenting}{13}{programs, documenting}
\entry{action, default}{14}{action, default}
\entry{pattern, default}{14}{pattern, default}
\entry{default action}{14}{default action}
\entry{default pattern}{14}{default pattern}
\entry{empty action}{14}{empty action}
\entry{action, empty}{14}{action, empty}
\entry{how awk works}{14}{how \code {awk} works}
\entry{csh, backslash continuation}{16}{\code {csh}, backslash continuation}
\entry{backslash continuation in csh}{16}{backslash continuation in \code {csh}}
\entry{automatic initialization}{16}{automatic initialization}
\entry{initialization, automatic}{16}{initialization, automatic}
\entry{line break}{17}{line break}
\entry{newline}{17}{newline}
\entry{backslash continuation}{17}{backslash continuation}
\entry{continuation of lines}{17}{continuation of lines}
\entry{line continuation}{17}{line continuation}
\entry{portability issues}{17}{portability issues}
\entry{csh, backslash continuation}{17}{\code {csh}, backslash continuation}
\entry{backslash continuation in csh}{17}{backslash continuation in \code {csh}}
\entry{backslash continuation and comments}{18}{backslash continuation and comments}
\entry{comments and backslash continuation}{18}{comments and backslash continuation}
\entry{multiple statements on one line}{18}{multiple statements on one line}
\entry{when to use awk}{19}{when to use \code {awk}}
\entry{applications of awk}{19}{applications of \code {awk}}
\entry{one-liners}{21}{one-liners}
\entry{pattern, regular expressions}{23}{pattern, regular expressions}
\entry{regexp}{23}{regexp}
\entry{regular expression}{23}{regular expression}
\entry{regular expressions as patterns}{23}{regular expressions as patterns}
\entry{regexp matching operators}{23}{regexp matching operators}
\entry{string-matching operators}{23}{string-matching operators}
\entry{operators, string-matching}{23}{operators, string-matching}
\entry{operators, regexp matching}{23}{operators, regexp matching}
\entry{regexp match/non-match operators}{23}{regexp match/non-match operators}
\entry{{\tt\char '176} operator}{23}{\code {~} operator}
\entry{!{\tt\char '176} operator}{23}{\code {!~} operator}
\entry{regexp constant}{24}{regexp constant}
\entry{escape sequence notation}{24}{escape sequence notation}
\entry{awk language, V.4 version}{24}{\code {awk} language, V.4 version}
\entry{awk language, V.4 version}{25}{\code {awk} language, V.4 version}
\entry{awk language, V.4 version}{25}{\code {awk} language, V.4 version}
\entry{awk language, POSIX version}{25}{\code {awk} language, POSIX version}
\entry{POSIX awk}{25}{POSIX \code {awk}}
\entry{portability issues}{26}{portability issues}
\entry{dark corner}{26}{dark corner}
\entry{metacharacters}{26}{metacharacters}
\entry{regular expression metacharacters}{26}{regular expression metacharacters}
\entry{regexp operators}{26}{regexp operators}
\entry{anchors in regexps}{27}{anchors in regexps}
\entry{regexp, anchors}{27}{regexp, anchors}
\entry{awk language, POSIX version}{27}{\code {awk} language, POSIX version}
\entry{POSIX awk}{27}{POSIX \code {awk}}
\entry{character list}{27}{character list}
\entry{egrep}{28}{\code {egrep}}
\entry{character classes}{28}{character classes}
\entry{awk language, POSIX version}{28}{\code {awk} language, POSIX version}
\entry{POSIX awk}{28}{POSIX \code {awk}}
\entry{collating elements}{29}{collating elements}
\entry{collating symbols}{29}{collating symbols}
\entry{equivalence classes}{29}{equivalence classes}
\entry{complemented character list}{29}{complemented character list}
\entry{character list, complemented}{29}{character list, complemented}
\entry{awk language, POSIX version}{31}{\code {awk} language, POSIX version}
\entry{POSIX awk}{31}{POSIX \code {awk}}
\entry{interval expressions}{31}{interval expressions}
\entry{precedence, regexp operators}{31}{precedence, regexp operators}
\entry{regexp operators, precedence of}{31}{regexp operators, precedence of}
\entry{regexp operators, GNU specific}{31}{regexp operators, GNU specific}
\entry{word, regexp definition of}{31}{word, regexp definition of}
\entry{{\tt\indexbackslash }w regexp operator}{32}{\code {{\tt\rawbackslashxx }w} regexp operator}
\entry{{\tt\indexbackslash }W regexp operator}{32}{\code {{\tt\rawbackslashxx }W} regexp operator}
\entry{{\tt\indexbackslash }{\tt\less} regexp operator}{32}{\code {{\tt\rawbackslashxx }<} regexp operator}
\entry{{\tt\indexbackslash }{\tt\gtr} regexp operator}{32}{\code {{\tt\rawbackslashxx }>} regexp operator}
\entry{{\tt\indexbackslash }y regexp operator}{32}{\code {{\tt\rawbackslashxx }y} regexp operator}
\entry{word boundaries, matching}{32}{word boundaries, matching}
\entry{{\tt\indexbackslash }B regexp operator}{32}{\code {{\tt\rawbackslashxx }B} regexp operator}
\entry{buffer matching operators}{32}{buffer matching operators}
\entry{{\tt\indexbackslash }` regexp operator}{32}{\code {{\tt\rawbackslashxx }`} regexp operator}
\entry{{\tt\indexbackslash }' regexp operator}{32}{\code {{\tt\rawbackslashxx }'} regexp operator}
\entry{regexp, effect of command line options}{32}{regexp, effect of command line options}
\entry{case sensitivity}{33}{case sensitivity}
\entry{ignoring case}{33}{ignoring case}
\entry{differences between gawk and awk}{33}{differences between \code {gawk} and \code {awk}}
\entry{{\tt\char '176} operator}{33}{\code {~} operator}
\entry{!{\tt\char '176} operator}{33}{\code {!~} operator}
\entry{IGNORECASE}{33}{\code {IGNORECASE}}
\entry{ISO 8859-1}{34}{ISO 8859-1}
\entry{ISO Latin-1}{34}{ISO Latin-1}
\entry{leftmost longest match}{34}{leftmost longest match}
\entry{matching, leftmost longest}{34}{matching, leftmost longest}
\entry{computed regular expressions}{35}{computed regular expressions}
\entry{regular expressions, computed}{35}{regular expressions, computed}
\entry{dynamic regular expressions}{35}{dynamic regular expressions}
\entry{regexp, dynamic}{35}{regexp, dynamic}
\entry{{\tt\char '176} operator}{35}{\code {~} operator}
\entry{!{\tt\char '176} operator}{35}{\code {!~} operator}
\entry{regexp constants, difference between slashes and quotes}{35}{regexp constants, difference between slashes and quotes}
\entry{common mistakes}{35}{common mistakes}
\entry{mistakes, common}{35}{mistakes, common}
\entry{errors, common}{35}{errors, common}
\entry{reading files}{37}{reading files}
\entry{input}{37}{input}
\entry{standard input}{37}{standard input}
\entry{FILENAME}{37}{\code {FILENAME}}
\entry{record separator, RS}{37}{record separator, \code {RS}}
\entry{changing the record separator}{37}{changing the record separator}
\entry{record, definition of}{37}{record, definition of}
\entry{RS}{37}{\code {RS}}
\entry{dark corner}{39}{dark corner}
\entry{empty string}{39}{empty string}
\entry{RT}{39}{\code {RT}}
\entry{record terminator, RT}{39}{record terminator, \code {RT}}
\entry{terminator, record}{39}{terminator, record}
\entry{differences between gawk and awk}{39}{differences between \code {gawk} and \code {awk}}
\entry{regular expressions as record separators}{39}{regular expressions as record separators}
\entry{differences between gawk and awk}{39}{differences between \code {gawk} and \code {awk}}
\entry{number of records, NR, FNR}{40}{number of records, \code {NR}, \code {FNR}}
\entry{NR}{40}{\code {NR}}
\entry{FNR}{40}{\code {FNR}}
\entry{examining fields}{40}{examining fields}
\entry{fields}{40}{fields}
\entry{accessing fields}{40}{accessing fields}
\entry{$ (field operator)}{40}{\code {$} (field operator)}
\entry{field operator $}{40}{field operator \code {$}}
\entry{NF}{40}{\code {NF}}
\entry{number of fields, NF}{40}{number of fields, \code {NF}}
\entry{field, changing contents of}{42}{field, changing contents of}
\entry{changing contents of a field}{42}{changing contents of a field}
\entry{assignment to fields}{42}{assignment to fields}
\entry{FS}{44}{\code {FS}}
\entry{fields, separating}{44}{fields, separating}
\entry{field separator, FS}{44}{field separator, \code {FS}}
\entry{common mistakes}{44}{common mistakes}
\entry{mistakes, common}{44}{mistakes, common}
\entry{errors, common}{44}{errors, common}
\entry{field separator, choice of}{45}{field separator, choice of}
\entry{regular expressions as field separators}{45}{regular expressions as field separators}
\entry{null string}{46}{null string}
\entry{empty string}{46}{empty string}
\entry{differences between gawk and awk}{46}{differences between \code {gawk} and \code {awk}}
\entry{single character fields}{46}{single character fields}
\entry{dark corner}{47}{dark corner}
\entry{-F option}{47}{\code {-F} option}
\entry{field separator, on command line}{47}{field separator, on command line}
\entry{command line, setting FS on}{47}{command line, setting \code {FS} on}
\entry{historical features}{47}{historical features}
\entry{awk language, POSIX version}{48}{\code {awk} language, POSIX version}
\entry{POSIX awk}{48}{POSIX \code {awk}}
\entry{dark corner}{48}{dark corner}
\entry{sed utility}{48}{\code {sed} utility}
\entry{stream editor}{48}{stream editor}
\entry{multiple line records}{51}{multiple line records}
\entry{input, multiple line records}{51}{input, multiple line records}
\entry{reading files, multiple line records}{51}{reading files, multiple line records}
\entry{records, multiple line}{51}{records, multiple line}
\entry{leftmost longest match}{51}{leftmost longest match}
\entry{matching, leftmost longest}{51}{matching, leftmost longest}
\entry{dark corner}{51}{dark corner}
\entry{RT}{53}{\code {RT}}
\entry{getline}{53}{\code {getline}}
\entry{input, explicit}{53}{input, explicit}
\entry{explicit input}{53}{explicit input}
\entry{input, getline command}{53}{input, \code {getline} command}
\entry{reading files, getline command}{53}{reading files, \code {getline} command}
\entry{ERRNO}{54}{\code {ERRNO}}
\entry{differences between gawk and awk}{54}{differences between \code {gawk} and \code {awk}}
\entry{getline, return values}{54}{\code {getline}, return values}
\entry{dark corner}{55}{dark corner}
\entry{input redirection}{56}{input redirection}
\entry{redirection of input}{56}{redirection of input}
\entry{input pipeline}{57}{input pipeline}
\entry{pipeline, input}{57}{pipeline, input}
\entry{differences between gawk and awk}{59}{differences between \code {gawk} and \code {awk}}
\entry{limitations}{59}{limitations}
\entry{implementation limits}{59}{implementation limits}
\entry{FILENAME}{59}{\code {FILENAME}}
\entry{dark corner}{59}{dark corner}
\entry{getline, setting FILENAME}{59}{\code {getline}, setting \code {FILENAME}}
\entry{FILENAME, being set by getline}{59}{\code {FILENAME}, being set by \code {getline}}
\entry{printing}{61}{printing}
\entry{output}{61}{output}
\entry{print statement}{61}{\code {print} statement}
\entry{common mistakes}{62}{common mistakes}
\entry{mistakes, common}{62}{mistakes, common}
\entry{errors, common}{62}{errors, common}
\entry{line continuation}{63}{line continuation}
\entry{output field separator, OFS}{63}{output field separator, \code {OFS}}
\entry{output record separator, ORS}{63}{output record separator, \code {ORS}}
\entry{OFS}{63}{\code {OFS}}
\entry{ORS}{63}{\code {ORS}}
\entry{OFMT}{64}{\code {OFMT}}
\entry{numeric output format}{64}{numeric output format}
\entry{format, numeric output}{64}{format, numeric output}
\entry{output format specifier, OFMT}{64}{output format specifier, \code {OFMT}}
\entry{dark corner}{64}{dark corner}
\entry{awk language, POSIX version}{64}{\code {awk} language, POSIX version}
\entry{POSIX awk}{64}{POSIX \code {awk}}
\entry{formatted output}{64}{formatted output}
\entry{output, formatted}{64}{output, formatted}
\entry{printf statement, syntax of}{65}{\code {printf} statement, syntax of}
\entry{format string}{65}{format string}
\entry{printf, format-control characters}{65}{\code {printf}, format-control characters}
\entry{format specifier}{65}{format specifier}
\entry{dark corner}{66}{dark corner}
\entry{printf, modifiers}{66}{\code {printf}, modifiers}
\entry{modifiers (in format specifiers)}{66}{modifiers (in format specifiers)}
\entry{dark corner}{67}{dark corner}
\entry{awk language, POSIX version}{68}{\code {awk} language, POSIX version}
\entry{POSIX awk}{68}{POSIX \code {awk}}
\entry{output redirection}{70}{output redirection}
\entry{redirection of output}{70}{redirection of output}
\entry{pipes for output}{71}{pipes for output}
\entry{output, piping}{71}{output, piping}
\entry{differences between gawk and awk}{71}{differences between \code {gawk} and \code {awk}}
\entry{limitations}{71}{limitations}
\entry{implementation limits}{71}{implementation limits}
\entry{standard input}{72}{standard input}
\entry{standard output}{72}{standard output}
\entry{standard error output}{72}{standard error output}
\entry{file descriptors}{72}{file descriptors}
\entry{differences between gawk and awk}{72}{differences between \code {gawk} and \code {awk}}
\entry{/dev/stdin}{72}{\file {/dev/stdin}}
\entry{/dev/stdout}{72}{\file {/dev/stdout}}
\entry{/dev/stderr}{72}{\file {/dev/stderr}}
\entry{/dev/fd}{72}{\file {/dev/fd}}
\entry{process information}{73}{process information}
\entry{/dev/pid}{73}{\file {/dev/pid}}
\entry{/dev/pgrpid}{73}{\file {/dev/pgrpid}}
\entry{/dev/ppid}{73}{\file {/dev/ppid}}
\entry{/dev/user}{73}{\file {/dev/user}}
\entry{closing input files and pipes}{74}{closing input files and pipes}
\entry{closing output files and pipes}{74}{closing output files and pipes}
\entry{close}{74}{\code {close}}
\entry{ERRNO}{75}{\code {ERRNO}}
\entry{differences between gawk and awk}{75}{differences between \code {gawk} and \code {awk}}
\entry{differences between gawk and awk}{75}{differences between \code {gawk} and \code {awk}}
\entry{portability issues}{75}{portability issues}
\entry{expression}{77}{expression}
\entry{constants, types of}{77}{constants, types of}
\entry{string constants}{77}{string constants}
\entry{numeric constant}{77}{numeric constant}
\entry{numeric value}{77}{numeric value}
\entry{differences between gawk and awk}{77}{differences between \code {gawk} and \code {awk}}
\entry{{\tt\char '176} operator}{77}{\code {~} operator}
\entry{!{\tt\char '176} operator}{77}{\code {!~} operator}
\entry{dark corner}{78}{dark corner}
\entry{differences between gawk and awk}{78}{differences between \code {gawk} and \code {awk}}
\entry{dark corner}{78}{dark corner}
\entry{variables, user-defined}{79}{variables, user-defined}
\entry{user-defined variables}{79}{user-defined variables}
\entry{dark corner}{80}{dark corner}
\entry{conversion of strings and numbers}{81}{conversion of strings and numbers}
\entry{null string}{81}{null string}
\entry{empty string}{81}{empty string}
\entry{type conversion}{81}{type conversion}
\entry{CONVFMT}{81}{\code {CONVFMT}}
\entry{dark corner}{81}{dark corner}
\entry{awk language, POSIX version}{82}{\code {awk} language, POSIX version}
\entry{POSIX awk}{82}{POSIX \code {awk}}
\entry{OFMT}{82}{\code {OFMT}}
\entry{arithmetic operators}{82}{arithmetic operators}
\entry{operators, arithmetic}{82}{operators, arithmetic}
\entry{addition}{82}{addition}
\entry{subtraction}{82}{subtraction}
\entry{multiplication}{82}{multiplication}
\entry{division}{82}{division}
\entry{remainder}{82}{remainder}
\entry{quotient}{82}{quotient}
\entry{exponentiation}{82}{exponentiation}
\entry{awk language, POSIX version}{82}{\code {awk} language, POSIX version}
\entry{POSIX awk}{82}{POSIX \code {awk}}
\entry{differences between gawk and awk}{83}{differences between \code {gawk} and \code {awk}}
\entry{Kernighan, Brian}{83}{Kernighan, Brian}
\entry{string operators}{83}{string operators}
\entry{operators, string}{83}{operators, string}
\entry{concatenation}{83}{concatenation}
\entry{assignment operators}{84}{assignment operators}
\entry{operators, assignment}{84}{operators, assignment}
\entry{expression, assignment}{84}{expression, assignment}
\entry{side effect}{84}{side effect}
\entry{lvalue}{84}{lvalue}
\entry{rvalue}{84}{rvalue}
\entry{types of variables}{84}{types of variables}
\entry{Rankin, Pat}{85}{Rankin, Pat}
\entry{awk language, POSIX version}{86}{\code {awk} language, POSIX version}
\entry{POSIX awk}{86}{POSIX \code {awk}}
\entry{increment operators}{87}{increment operators}
\entry{operators, increment}{87}{operators, increment}
\entry{decrement operators}{87}{decrement operators}
\entry{operators, decrement}{87}{operators, decrement}
\entry{truth values}{88}{truth values}
\entry{logical true}{88}{logical true}
\entry{logical false}{88}{logical false}
\entry{null string}{88}{null string}
\entry{empty string}{88}{empty string}
\entry{dark corner}{88}{dark corner}
\entry{comparison expressions}{88}{comparison expressions}
\entry{expression, comparison}{88}{expression, comparison}
\entry{expression, matching}{88}{expression, matching}
\entry{relational operators}{88}{relational operators}
\entry{operators, relational}{88}{operators, relational}
\entry{regexp match/non-match operators}{88}{regexp match/non-match operators}
\entry{variable typing}{88}{variable typing}
\entry{types of variables}{88}{types of variables}
\entry{numeric string}{88}{numeric string}
\entry{relational operators}{89}{relational operators}
\entry{operators, relational}{89}{operators, relational}
\entry{{\tt\less} operator}{89}{\code {<} operator}
\entry{{\tt\less}= operator}{89}{\code {<=} operator}
\entry{{\tt\gtr} operator}{89}{\code {>} operator}
\entry{{\tt\gtr}= operator}{89}{\code {>=} operator}
\entry{== operator}{89}{\code {==} operator}
\entry{!= operator}{89}{\code {!=} operator}
\entry{{\tt\char '176} operator}{89}{\code {~} operator}
\entry{!{\tt\char '176} operator}{89}{\code {!~} operator}
\entry{in operator}{89}{\code {in} operator}
\entry{common mistakes}{90}{common mistakes}
\entry{mistakes, common}{90}{mistakes, common}
\entry{errors, common}{90}{errors, common}
\entry{comparisons, string vs. regexp}{90}{comparisons, string vs. regexp}
\entry{string comparison vs. regexp comparison}{90}{string comparison vs. regexp comparison}
\entry{regexp comparison vs. string comparison}{90}{regexp comparison vs. string comparison}
\entry{regexp as expression}{91}{regexp as expression}
\entry{expression, boolean}{91}{expression, boolean}
\entry{boolean expressions}{91}{boolean expressions}
\entry{operators, boolean}{91}{operators, boolean}
\entry{boolean operators}{91}{boolean operators}
\entry{logical operations}{91}{logical operations}
\entry{operations, logical}{91}{operations, logical}
\entry{short-circuit operators}{91}{short-circuit operators}
\entry{operators, short-circuit}{91}{operators, short-circuit}
\entry{and operator}{91}{and operator}
\entry{or operator}{91}{or operator}
\entry{not operator}{91}{not operator}
\entry{&& operator}{91}{\code {&&} operator}
\entry{{\tt\char '174}{\tt\char '174} operator}{91}{\code {||} operator}
\entry{! operator}{91}{\code {!} operator}
\entry{line continuation}{92}{line continuation}
\entry{conditional expression}{92}{conditional expression}
\entry{expression, conditional}{92}{expression, conditional}
\entry{differences between gawk and awk}{93}{differences between \code {gawk} and \code {awk}}
\entry{line continuation}{93}{line continuation}
\entry{function call}{93}{function call}
\entry{calling a function}{93}{calling a function}
\entry{arguments in function call}{93}{arguments in function call}
\entry{precedence}{94}{precedence}
\entry{operator precedence}{94}{operator precedence}
\entry{awk language, POSIX version}{95}{\code {awk} language, POSIX version}
\entry{POSIX awk}{95}{POSIX \code {awk}}
\entry{awk language, POSIX version}{96}{\code {awk} language, POSIX version}
\entry{POSIX awk}{96}{POSIX \code {awk}}
\entry{pattern, definition of}{97}{pattern, definition of}
\entry{patterns, types of}{97}{patterns, types of}
\entry{range pattern}{99}{range pattern}
\entry{pattern, range}{99}{pattern, range}
\entry{matching ranges of lines}{99}{matching ranges of lines}
\entry{skipping lines between markers}{100}{skipping lines between markers}
\entry{BEGIN special pattern}{100}{\code {BEGIN} special pattern}
\entry{pattern, BEGIN}{100}{pattern, \code {BEGIN}}
\entry{END special pattern}{100}{\code {END} special pattern}
\entry{pattern, END}{100}{pattern, \code {END}}
\entry{dark corner}{101}{dark corner}
\entry{I/O from BEGIN and END}{102}{I/O from \code {BEGIN} and \code {END}}
\entry{differences between gawk and awk}{102}{differences between \code {gawk} and \code {awk}}
\entry{empty pattern}{102}{empty pattern}
\entry{pattern, empty}{102}{pattern, empty}
\entry{action, definition of}{102}{action, definition of}
\entry{curly braces}{102}{curly braces}
\entry{action, curly braces}{102}{action, curly braces}
\entry{action, separating statements}{102}{action, separating statements}
\entry{control statement}{105}{control statement}
\entry{compound statement}{105}{compound statement}
\entry{statement, compound}{105}{statement, compound}
\entry{if-else statement}{105}{\code {if}-\code {else} statement}
\entry{while statement}{106}{\code {while} statement}
\entry{loop}{106}{loop}
\entry{body of a loop}{106}{body of a loop}
\entry{for statement}{107}{\code {for} statement}
\entry{break statement}{109}{\code {break} statement}
\entry{loops, exiting}{109}{loops, exiting}
\entry{break, outside of loops}{109}{\code {break}, outside of loops}
\entry{historical features}{109}{historical features}
\entry{awk language, POSIX version}{109}{\code {awk} language, POSIX version}
\entry{POSIX awk}{109}{POSIX \code {awk}}
\entry{dark corner}{109}{dark corner}
\entry{continue statement}{110}{\code {continue} statement}
\entry{continue, outside of loops}{110}{\code {continue}, outside of loops}
\entry{historical features}{110}{historical features}
\entry{awk language, POSIX version}{110}{\code {awk} language, POSIX version}
\entry{POSIX awk}{110}{POSIX \code {awk}}
\entry{dark corner}{110}{dark corner}
\entry{next statement}{111}{\code {next} statement}
\entry{awk language, POSIX version}{111}{\code {awk} language, POSIX version}
\entry{POSIX awk}{111}{POSIX \code {awk}}
\entry{next, inside a user-defined function}{111}{\code {next}, inside a user-defined function}
\entry{nextfile statement}{112}{\code {nextfile} statement}
\entry{differences between gawk and awk}{112}{differences between \code {gawk} and \code {awk}}
\entry{next file statement}{112}{\code {next file} statement}
\entry{exit statement}{112}{\code {exit} statement}
\entry{dark corner}{113}{dark corner}
\entry{built-in variables}{115}{built-in variables}
\entry{built-in variables, user modifiable}{115}{built-in variables, user modifiable}
\entry{CONVFMT}{115}{\code {CONVFMT}}
\entry{awk language, POSIX version}{115}{\code {awk} language, POSIX version}
\entry{POSIX awk}{115}{POSIX \code {awk}}
\entry{FIELDWIDTHS}{115}{\code {FIELDWIDTHS}}
\entry{FS}{115}{\code {FS}}
\entry{IGNORECASE}{116}{\code {IGNORECASE}}
\entry{OFMT}{116}{\code {OFMT}}
\entry{OFS}{116}{\code {OFS}}
\entry{ORS}{116}{\code {ORS}}
\entry{RS}{116}{\code {RS}}
\entry{SUBSEP}{117}{\code {SUBSEP}}
\entry{built-in variables, convey information}{117}{built-in variables, convey information}
\entry{ARGC}{117}{\code {ARGC}}
\entry{ARGV}{117}{\code {ARGV}}
\entry{ARGIND}{117}{\code {ARGIND}}
\entry{ENVIRON}{118}{\code {ENVIRON}}
\entry{ERRNO}{118}{\code {ERRNO}}
\entry{dark corner}{118}{dark corner}
\entry{FILENAME}{118}{\code {FILENAME}}
\entry{FNR}{118}{\code {FNR}}
\entry{NF}{118}{\code {NF}}
\entry{NR}{119}{\code {NR}}
\entry{RLENGTH}{119}{\code {RLENGTH}}
\entry{RSTART}{119}{\code {RSTART}}
\entry{RT}{119}{\code {RT}}
\entry{dark corner}{119}{dark corner}
\entry{differences between gawk and awk}{121}{differences between \code {gawk} and \code {awk}}
\entry{arrays}{123}{arrays}
\entry{arrays, definition of}{123}{arrays, definition of}
\entry{associative arrays}{123}{associative arrays}
\entry{arrays, associative}{123}{arrays, associative}
\entry{sparse arrays}{124}{sparse arrays}
\entry{arrays, sparse}{124}{arrays, sparse}
\entry{Array subscripts and IGNORECASE}{124}{Array subscripts and \code {IGNORECASE}}
\entry{IGNORECASE and array subscripts}{124}{\code {IGNORECASE} and array subscripts}
\entry{IGNORECASE}{124}{\code {IGNORECASE}}
\entry{array reference}{124}{array reference}
\entry{element of array}{124}{element of array}
\entry{reference to array}{124}{reference to array}
\entry{arrays, presence of elements}{125}{arrays, presence of elements}
\entry{arrays, the in operator}{125}{arrays, the \code {in} operator}
\entry{array assignment}{125}{array assignment}
\entry{element assignment}{125}{element assignment}
\entry{for (x in ...{})}{127}{\code {for (x in \dots {})}}
\entry{arrays, special for statement}{127}{arrays, special \code {for} statement}
\entry{scanning an array}{127}{scanning an array}
\entry{delete statement}{128}{\code {delete} statement}
\entry{deleting elements of arrays}{128}{deleting elements of arrays}
\entry{removing elements of arrays}{128}{removing elements of arrays}
\entry{arrays, deleting an element}{128}{arrays, deleting an element}
\entry{arrays, deleting entire contents}{128}{arrays, deleting entire contents}
\entry{deleting entire arrays}{128}{deleting entire arrays}
\entry{differences between gawk and awk}{128}{differences between \code {gawk} and \code {awk}}
\entry{portability issues}{128}{portability issues}
\entry{Brennan, Michael}{128}{Brennan, Michael}
\entry{conversions, during subscripting}{129}{conversions, during subscripting}
\entry{numbers, used as subscripts}{129}{numbers, used as subscripts}
\entry{CONVFMT}{129}{\code {CONVFMT}}
\entry{uninitialized variables, as array subscripts}{130}{uninitialized variables, as array subscripts}
\entry{array subscripts, uninitialized variables}{130}{array subscripts, uninitialized variables}
\entry{null string, as array subscript}{130}{null string, as array subscript}
\entry{dark corner}{130}{dark corner}
\entry{subscripts in arrays}{130}{subscripts in arrays}
\entry{arrays, multi-dimensional subscripts}{130}{arrays, multi-dimensional subscripts}
\entry{multi-dimensional subscripts}{130}{multi-dimensional subscripts}
\entry{SUBSEP}{130}{\code {SUBSEP}}
\entry{built-in functions}{135}{built-in functions}
\entry{differences between gawk and awk}{135}{differences between \code {gawk} and \code {awk}}
\entry{evaluation, order of}{135}{evaluation, order of}
\entry{order of evaluation}{135}{order of evaluation}
\entry{int}{136}{\code {int}}
\entry{sqrt}{136}{\code {sqrt}}
\entry{exp}{136}{\code {exp}}
\entry{log}{136}{\code {log}}
\entry{sin}{136}{\code {sin}}
\entry{cos}{136}{\code {cos}}
\entry{atan2}{136}{\code {atan2}}
\entry{rand}{136}{\code {rand}}
\entry{seed for random numbers}{137}{seed for random numbers}
\entry{random numbers, seed of}{137}{random numbers, seed of}
\entry{srand}{137}{\code {srand}}
\entry{index}{137}{\code {index}}
\entry{length}{138}{\code {length}}
\entry{historical features}{138}{historical features}
\entry{portability issues}{138}{portability issues}
\entry{awk language, POSIX version}{138}{\code {awk} language, POSIX version}
\entry{POSIX awk}{138}{POSIX \code {awk}}
\entry{match}{138}{\code {match}}
\entry{RSTART}{138}{\code {RSTART}}
\entry{RLENGTH}{138}{\code {RLENGTH}}
\entry{split}{139}{\code {split}}
\entry{differences between gawk and awk}{139}{differences between \code {gawk} and \code {awk}}
\entry{dark corner}{139}{dark corner}
\entry{sprintf}{140}{\code {sprintf}}
\entry{sub}{140}{\code {sub}}
\entry{sub, third argument of}{141}{\code {sub}, third argument of}
\entry{gsub, third argument of}{141}{\code {gsub}, third argument of}
\entry{gsub}{141}{\code {gsub}}
\entry{gensub}{141}{\code {gensub}}
\entry{differences between gawk and awk}{142}{differences between \code {gawk} and \code {awk}}
\entry{substr}{142}{\code {substr}}
\entry{case conversion}{143}{case conversion}
\entry{conversion of case}{143}{conversion of case}
\entry{tolower}{143}{\code {tolower}}
\entry{toupper}{143}{\code {toupper}}
\entry{escape processing, sub et. al.}{143}{escape processing, \code {sub} et. al.}
\entry{awk language, POSIX version}{144}{\code {awk} language, POSIX version}
\entry{POSIX awk}{144}{POSIX \code {awk}}
\entry{close}{146}{\code {close}}
\entry{fflush}{146}{\code {fflush}}
\entry{portability issues}{146}{portability issues}
\entry{flushing buffers}{146}{flushing buffers}
\entry{buffers, flushing}{146}{buffers, flushing}
\entry{buffering output}{146}{buffering output}
\entry{output, buffering}{146}{output, buffering}
\entry{system}{146}{\code {system}}
\entry{interaction, awk and other programs}{146}{interaction, \code {awk} and other programs}
\entry{buffering, interactive vs. non-interactive}{147}{buffering, interactive vs. non-interactive}
\entry{buffering, non-interactive vs. interactive}{147}{buffering, non-interactive vs. interactive}
\entry{interactive buffering vs. non-interactive}{147}{interactive buffering vs. non-interactive}
\entry{non-interactive buffering vs. interactive}{147}{non-interactive buffering vs. interactive}
\entry{flushing buffers}{148}{flushing buffers}
\entry{buffers, flushing}{148}{buffers, flushing}
\entry{buffering output}{148}{buffering output}
\entry{output, buffering}{148}{output, buffering}
\entry{timestamps}{148}{timestamps}
\entry{time of day}{148}{time of day}
\entry{systime}{149}{\code {systime}}
\entry{strftime}{149}{\code {strftime}}
\entry{locale, definition of}{150}{locale, definition of}
\entry{ISO 8601}{151}{ISO 8601}
\entry{RFC-822}{152}{RFC-822}
\entry{RFC-1036}{152}{RFC-1036}
\entry{user-defined functions}{153}{user-defined functions}
\entry{functions, user-defined}{153}{functions, user-defined}
\entry{defining functions}{153}{defining functions}
\entry{function definition}{153}{function definition}
\entry{names, use of}{153}{names, use of}
\entry{namespaces}{153}{namespaces}
\entry{variable shadowing}{154}{variable shadowing}
\entry{recursive function}{154}{recursive function}
\entry{function, recursive}{154}{function, recursive}
\entry{awk language, POSIX version}{154}{\code {awk} language, POSIX version}
\entry{POSIX awk}{154}{POSIX \code {awk}}
\entry{portability issues}{154}{portability issues}
\entry{call by value}{156}{call by value}
\entry{call by reference}{156}{call by reference}
\entry{calling a function}{156}{calling a function}
\entry{function call}{156}{function call}
\entry{call by value}{156}{call by value}
\entry{call by reference}{157}{call by reference}
\entry{undefined functions}{157}{undefined functions}
\entry{functions, undefined}{157}{functions, undefined}
\entry{return statement}{158}{\code {return} statement}
\entry{command line}{161}{command line}
\entry{invocation of gawk}{161}{invocation of \code {gawk}}
\entry{arguments, command line}{161}{arguments, command line}
\entry{options, command line}{161}{options, command line}
\entry{long options}{161}{long options}
\entry{options, long}{161}{options, long}
\entry{empty program}{161}{empty program}
\entry{dark corner}{161}{dark corner}
\entry{-F option}{161}{\code {-F} option}
\entry{--field-separator option}{161}{\code {--field-separator} option}
\entry{-f option}{161}{\code {-f} option}
\entry{--file option}{161}{\code {--file} option}
\entry{-v option}{161}{\code {-v} option}
\entry{--assign option}{161}{\code {--assign} option}
\entry{-W option}{162}{\code {-W} option}
\entry{--compat option}{162}{\code {--compat} option}
\entry{--traditional option}{162}{\code {--traditional} option}
\entry{compatibility mode}{162}{compatibility mode}
\entry{--copyleft option}{162}{\code {--copyleft} option}
\entry{--copyright option}{162}{\code {--copyright} option}
\entry{--help option}{163}{\code {--help} option}
\entry{--usage option}{163}{\code {--usage} option}
\entry{--lint option}{163}{\code {--lint} option}
\entry{--lint-old option}{163}{\code {--lint-old} option}
\entry{--posix option}{163}{\code {--posix} option}
\entry{POSIX mode}{163}{POSIX mode}
\entry{--source option}{164}{\code {--source} option}
\entry{--version option}{164}{\code {--version} option}
\entry{POSIXLY{\_}CORRECT environment variable}{164}{\code {POSIXLY_CORRECT} environment variable}
\entry{environment variable, POSIXLY{\_}CORRECT}{164}{environment variable, \code {POSIXLY_CORRECT}}
\entry{ARGIND}{165}{\code {ARGIND}}
\entry{ARGV}{165}{\code {ARGV}}
\entry{dark corner}{165}{dark corner}
\entry{multiple passes over data}{166}{multiple passes over data}
\entry{passes, multiple}{166}{passes, multiple}
\entry{AWKPATH environment variable}{166}{\code {AWKPATH} environment variable}
\entry{environment variable, AWKPATH}{166}{environment variable, \code {AWKPATH}}
\entry{search path}{166}{search path}
\entry{directory search}{166}{directory search}
\entry{path, search}{166}{path, search}
\entry{differences between gawk and awk}{166}{differences between \code {gawk} and \code {awk}}
\entry{search path, for source files}{166}{search path, for source files}
\entry{deprecated options}{167}{deprecated options}
\entry{obsolete options}{167}{obsolete options}
\entry{deprecated features}{167}{deprecated features}
\entry{obsolete features}{167}{obsolete features}
\entry{undocumented features}{167}{undocumented features}
\entry{bugs, known in gawk}{167}{bugs, known in \code {gawk}}
\entry{known bugs}{167}{known bugs}
\entry{portability issues}{169}{portability issues}
\entry{skipping input files}{170}{skipping input files}
\entry{input files, skipping}{170}{input files, skipping}
\entry{nextfile function}{170}{\code {nextfile} function}
\entry{assertions}{172}{assertions}
\entry{assert, C version}{172}{\code {assert}, C version}
\entry{assert}{172}{\code {assert}}
\entry{rounding}{173}{rounding}
\entry{round}{173}{\code {round}}
\entry{numeric character values}{174}{numeric character values}
\entry{values of characters as numbers}{174}{values of characters as numbers}
\entry{ord}{174}{\code {ord}}
\entry{chr}{174}{\code {chr}}
\entry{character sets}{175}{character sets}
\entry{character encodings}{175}{character encodings}
\entry{ASCII}{175}{ASCII}
\entry{EBCDIC}{175}{EBCDIC}
\entry{mark parity}{175}{mark parity}
\entry{merging strings}{176}{merging strings}
\entry{join}{177}{\code {join}}
\entry{converting dates to timestamps}{177}{converting dates to timestamps}
\entry{dates, converting to timestamps}{177}{dates, converting to timestamps}
\entry{timestamps, converting from dates}{177}{timestamps, converting from dates}
\entry{{\_}tm{\_}isleap}{178}{\code {_tm_isleap}}
\entry{{\_}tm{\_}addup}{179}{\code {_tm_addup}}
\entry{mktime}{180}{\code {mktime}}
\entry{formatted timestamps}{183}{formatted timestamps}
\entry{timestamps, formatted}{183}{timestamps, formatted}
\entry{gettimeofday}{183}{\code {gettimeofday}}
\entry{per file initialization and clean-up}{185}{per file initialization and clean-up}
\entry{beginfile}{186}{\code {beginfile}}
\entry{endfile}{186}{\code {endfile}}
\entry{getopt, C version}{186}{\code {getopt}, C version}
\entry{processing arguments}{186}{processing arguments}
\entry{argument processing}{186}{argument processing}
\entry{getopt}{189}{\code {getopt}}
\entry{/dev/user}{192}{\file {/dev/user}}
\entry{getpwent, C version}{192}{\code {getpwent}, C version}
\entry{user information}{192}{user information}
\entry{login information}{192}{login information}
\entry{account information}{192}{account information}
\entry{password file}{192}{password file}
\entry{pwcat program}{193}{\code {pwcat} program}
\entry{pwcat.c}{193}{\code {pwcat.c}}
\entry{{\_}pw{\_}init}{194}{\code {_pw_init}}
\entry{getpwnam}{195}{\code {getpwnam}}
\entry{getpwuid}{196}{\code {getpwuid}}
\entry{getpwent}{196}{\code {getpwent}}
\entry{endpwent}{196}{\code {endpwent}}
\entry{getgrent, C version}{197}{\code {getgrent}, C version}
\entry{group information}{197}{group information}
\entry{account information}{197}{account information}
\entry{group file}{197}{group file}
\entry{grcat program}{197}{\code {grcat} program}
\entry{grcat.c}{197}{\code {grcat.c}}
\entry{{\_}gr{\_}init}{199}{\code {_gr_init}}
\entry{getgrnam}{200}{\code {getgrnam}}
\entry{getgrgid}{201}{\code {getgrgid}}
\entry{getgruser}{201}{\code {getgruser}}
\entry{getgrent}{201}{\code {getgrent}}
\entry{endgrent}{201}{\code {endgrent}}
\entry{namespace issues in awk}{202}{namespace issues in \code {awk}}
\entry{documenting awk programs}{202}{documenting \code {awk} programs}
\entry{programs, documenting}{202}{programs, documenting}
\entry{Tcl}{203}{Tcl}
\entry{cut utility}{205}{\code {cut} utility}
\entry{cut.awk}{206}{\code {cut.awk}}
\entry{egrep utility}{210}{\code {egrep} utility}
\entry{egrep.awk}{211}{\code {egrep.awk}}
\entry{backslash continuation}{214}{backslash continuation}
\entry{id utility}{215}{\code {id} utility}
\entry{id.awk}{215}{\code {id.awk}}
\entry{split utility}{217}{\code {split} utility}
\entry{split.awk}{217}{\code {split.awk}}
\entry{tee utility}{219}{\code {tee} utility}
\entry{tee.awk}{219}{\code {tee.awk}}
\entry{uniq utility}{220}{\code {uniq} utility}
\entry{uniq.awk}{221}{\code {uniq.awk}}
\entry{wc utility}{225}{\code {wc} utility}
\entry{wc.awk}{225}{\code {wc.awk}}
\entry{dupword.awk}{228}{\code {dupword.awk}}
\entry{alarm.awk}{229}{\code {alarm.awk}}
\entry{translate.awk}{232}{\code {translate.awk}}
\entry{labels.awk}{234}{\code {labels.awk}}
\entry{wordfreq.sh}{237}{\code {wordfreq.sh}}
\entry{Rakitzis, Byron}{238}{Rakitzis, Byron}
\entry{histsort.awk}{238}{\code {histsort.awk}}
\entry{extract.awk}{240}{\code {extract.awk}}
\entry{sed utility}{242}{\code {sed} utility}
\entry{Brennan, Michael}{243}{Brennan, Michael}
\entry{awksed}{243}{\code {awksed}}
\entry{simple stream editor}{243}{simple stream editor}
\entry{stream editor, simple}{243}{stream editor, simple}
\entry{sed utility}{246}{\code {sed} utility}
\entry{igawk.sh}{246}{\code {igawk.sh}}
\entry{awk language, V.4 version}{254}{\code {awk} language, V.4 version}
\entry{Kernighan, Brian}{255}{Kernighan, Brian}
\entry{compatibility mode}{256}{compatibility mode}
\entry{historical features}{277}{historical features}
\entry{getting gawk}{279}{getting \code {gawk}}
\entry{anonymous ftp}{279}{anonymous \code {ftp}}
\entry{ftp, anonymous}{279}{\code {ftp}, anonymous}
\entry{Free Software Foundation}{279}{Free Software Foundation}
\entry{Free Software Foundation}{279}{Free Software Foundation}
\entry{artificial intelligence, using gawk}{282}{artificial intelligence, using \code {gawk}}
\entry{AI programming, using gawk}{282}{AI programming, using \code {gawk}}
\entry{installation, unix}{284}{installation, unix}
\entry{configuring gawk}{285}{configuring \code {gawk}}
\entry{custom.h configuration file}{285}{\code {custom.h} configuration file}
\entry{installation, vms}{285}{installation, vms}
\entry{installation, MS-DOS and OS/2}{288}{installation, MS-DOS and OS/2}
\entry{atari}{289}{atari}
\entry{installation, atari}{289}{installation, atari}
\entry{Linux}{290}{Linux}
\entry{amiga}{291}{amiga}
\entry{installation, amiga}{291}{installation, amiga}
\entry{comp.lang.awk}{292}{\code {comp.lang.awk}}
\entry{Deifik, Scott}{293}{Deifik, Scott}
\entry{Fish, Fred}{293}{Fish, Fred}
\entry{Hankerson, Darrel}{293}{Hankerson, Darrel}
\entry{Jaegermann, Michal}{293}{Jaegermann, Michal}
\entry{Rankin, Pat}{293}{Rankin, Pat}
\entry{Rommel, Kai Uwe}{293}{Rommel, Kai Uwe}
\entry{Brennan, Michael}{293}{Brennan, Michael}
\entry{Kernighan, Brian}{293}{Kernighan, Brian}
\entry{anonymous ftp}{293}{anonymous \code {ftp}}
\entry{ftp, anonymous}{293}{\code {ftp}, anonymous}
\entry{Brennan, Michael}{293}{Brennan, Michael}
\entry{mawk}{293}{\code {mawk}}
\entry{adding new features}{295}{adding new features}
\entry{features, adding}{295}{features, adding}
\entry{gawk coding style}{296}{\code {gawk} coding style}
\entry{coding style used in gawk}{296}{coding style used in \code {gawk}}
\entry{porting gawk}{297}{porting \code {gawk}}
\entry{PERL}{299}{PERL}
\entry{Wall, Larry}{299}{Wall, Larry}
\entry{ISO 8859-1}{302}{ISO 8859-1}
\entry{ISO Latin-1}{302}{ISO Latin-1}
