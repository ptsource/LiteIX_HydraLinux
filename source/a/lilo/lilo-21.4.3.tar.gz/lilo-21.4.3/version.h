/* version.h   */

#ifndef VERSION_H
#define VERSION_H

#define VERSION_MAJOR 21
#define VERSION_MINOR 4
#define VERSION_EDIT  "-3"
#define VERSION_DATE "06-May-2000"

#endif
