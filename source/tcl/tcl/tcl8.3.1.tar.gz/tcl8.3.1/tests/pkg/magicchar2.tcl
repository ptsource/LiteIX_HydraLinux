proc {[magic mojo proc]} {} {}
