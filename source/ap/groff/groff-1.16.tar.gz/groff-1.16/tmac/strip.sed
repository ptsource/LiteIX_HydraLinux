/%beginstrip%/,$s/[	 ]*\\".*//
/^\.$/d
