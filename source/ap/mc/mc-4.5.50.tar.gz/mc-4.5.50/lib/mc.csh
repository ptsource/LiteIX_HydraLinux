alias mc 'setenv MC `/gnome/bin/mc -P \!*`; cd $MC; unsetenv MC'

