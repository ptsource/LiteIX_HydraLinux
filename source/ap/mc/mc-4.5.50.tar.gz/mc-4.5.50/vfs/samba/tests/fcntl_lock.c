/* test whether fcntl locking works on this system */

#if defined(HAVE_UNISTD_H)
#include <unistd.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>

#ifdef HAVE_FCNTL_H
#include <fcntl.h>
#endif

#ifdef HAVE_SYS_FCNTL_H
#include <sys/fcntl.h>
#endif

#include <errno.h>

static int sys_waitpid(pid_t pid,int *status,int options)
{
#ifdef HAVE_WAITPID
  return waitpid(pid,status,options);
#else /* USE_WAITPID */
  return wait4(pid, status, options, NULL);
#endif /* USE_WAITPID */
}

#define DATA "conftest.fcntl"

#ifndef SEEK_SET
#define SEEK_SET 0
#endif

/* lock a byte range in a open file */
int main(int argc, char *argv[])
{
	struct flock lock;
	int fd, pid, ret, status=1;

	if (!(pid=fork())) {
		sleep(2);
		fd = open(DATA, O_RDONLY);

		if (fd == -1) exit(1);

		lock.l_type = F_WRLCK;
		lock.l_whence = SEEK_SET;
		lock.l_start = 0;
		lock.l_len = 4;
		lock.l_pid = getpid();
		
		lock.l_type = F_WRLCK;
		
		/* check if a lock applies */
		ret = fcntl(fd,F_GETLK,&lock);

		if ((ret == -1) ||
		    (lock.l_type == F_UNLCK)) {
			exit(1);
		} else {
			exit(0);
		}
	}

	fd = open(DATA, O_RDWR|O_CREAT|O_TRUNC, 0600);

	lock.l_type = F_WRLCK;
	lock.l_whence = SEEK_SET;
	lock.l_start = 0;
	lock.l_len = 4;
	lock.l_pid = getpid();

	/* set a 4 byte write lock */
	fcntl(fd,F_SETLK,&lock);

	sys_waitpid(pid, &status, 0);

	unlink(DATA);

	exit(status);
}
