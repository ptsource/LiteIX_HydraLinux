/**
 *
 * $Id: Obsolete.c,v 1.8 1999/06/06 02:36:50 rwscott Exp $
 *
 * Copyright (C) 1997 Free Software Foundation, Inc.
 *
 * This file is part of the GNU LessTif Library.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 **/

static const char rcsid[] = "$Id: Obsolete.c,v 1.8 1999/06/06 02:36:50 rwscott Exp $";

#include <LTconfig.h>

#include <Xm/XmP.h>
#include <Xm/Text.h>
#include <Xm/TextF.h>

/* This file contains functions from previous versions that are now obsolete */

/* For the prototype police */
extern int XmTextFieldGetBaseLine(Widget w);
extern int XmTextGetBaseLine(Widget w);

int
XmTextFieldGetBaseLine(Widget w)
{
    return XmTextFieldGetBaseline(w);
}

int
XmTextGetBaseLine(Widget w)
{
    return XmTextGetBaseline(w);
}

static void
GenericMessage(String func)
{
    _XmWarning(NULL, "%s - This function is considered obsolete. Update your sources\n", func);
}

void
_XmChangeNavigationType(Widget w, XmNavigationType nav_type)
{
static Boolean FirstCall = True;

    if (FirstCall)
    {
    	GenericMessage("_XmChangeNavigationType");
    	FirstCall = False;
    }
}

void
_XmDrawShadowType(Widget w, unsigned int type, Dimension width, Dimension height, Dimension shadow_thickness, Dimension highlight_thickness, GC top_gc, GC bottom_gc)
{
	_XmDrawShadows(XtDisplay(w),
		XtWindow(w),
		top_gc,
		bottom_gc,
		highlight_thickness, highlight_thickness,
		width - (2 * highlight_thickness), height - (2 * highlight_thickness),
		shadow_thickness,
		type);
}
