/**
 *
 * $Id: ReadImage.c,v 1.2 1998/09/12 15:05:37 rwscott Exp $
 *
 * Copyright (C) 1995 Free Software Foundation, Inc.
 *
 * This file is part of the GNU LessTif Library.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 **/

static const char rcsid[] = "$Id: ReadImage.c,v 1.2 1998/09/12 15:05:37 rwscott Exp $";

#include <LTconfig.h>
#include <XmI/XmI.h>

#include <Xm/XmP.h>
#include <XmI/DragDropI.h>

#include <XmI/DebugUtil.h>

XImage *
_XmGetImageFromFile(char *filename)
{
    return NULL;
}

XImage *
_XmGetImageAndHotSpotFromFile(char *filename, int *hot_x, int *hot_y)
{
    return NULL;
}
