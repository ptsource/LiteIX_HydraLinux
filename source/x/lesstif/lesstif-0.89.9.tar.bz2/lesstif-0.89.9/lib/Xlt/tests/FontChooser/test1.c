#include <stdlib.h>
#include <stdio.h>
#include <../../lib/Xlt.h>
#include <../../lib/FontChooser.h>


static char *FallBack[] =
{
	NULL
};

int
main(int argc, char **argv)
{
  Widget toplevel, one;
  XtAppContext app;

  XtSetLanguageProc(NULL, NULL, NULL);

  toplevel = XtVaAppInitialize(&app, "FontChooser", NULL, 0, &argc,
			       argv, FallBack, NULL); 

  one = XltCreateFontChooser(toplevel, "FontChooser", NULL, 0);
  XtManageChild(one);

  XtRealizeWidget(toplevel);
  XtAppMainLoop(app);
  exit(0);
}
