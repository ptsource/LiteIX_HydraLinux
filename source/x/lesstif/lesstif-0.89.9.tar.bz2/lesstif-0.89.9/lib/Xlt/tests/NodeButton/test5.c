/* $Id: test5.c,v 1.3 1999/10/26 09:16:28 amai Exp $ */

#include <stdlib.h>
#include <Host.h>
#include <Xm/PushB.h>
#include <Xm/Label.h>
#include <Xm/RowColumn.h>
#include <Xm/ScrolledW.h>
#include <NodeButton.h>
#include <stdio.h>

#ifdef HAS_STROKE
#include <Stroke.h>
#endif

static char *FallBack[] =
{
#ifdef HAS_STROKE
	"*.strokes: 654 ManagerParentCancel, 456 ManagerParentActivate",
	"*NodeButton1.strokes: 852 Up, 258 Down, 456 Up, 654 Down",
	"*XmDialogShell*translations: #override" DEFAULT_STROKE_TRANSLATIONS,
#endif
	NULL
};

void
debug()
{
}

static void
Activate()
{
	printf("Activate()\n");
}

char *Program = "";
int
main(int argc, char **argv)
{
  Widget toplevel, rc, scrollWind, one;
  XtAppContext app;

  XtSetLanguageProc(NULL, NULL, NULL);

  toplevel = XtVaAppInitialize(&app, "NodeButtonTest", NULL, 0, &argc, argv, FallBack, NULL);
  XtVaSetValues(toplevel,
  	XmNallowShellResize, True,
  	NULL);

  scrollWind = XmCreateScrolledWindow(toplevel, "Window", NULL, 0);
  rc = XmCreateRowColumn(scrollWind, "rc", NULL, 0);
  one = XltCreateNodeButton(rc, "NodeButton1", NULL, 0);
#ifdef HAS_STROKE
  StrokeInitialize(toplevel);
#endif

  XtVaCreateManagedWidget("Two", xmPushButtonWidgetClass, one, NULL );
  XtVaCreateManagedWidget("Three", xmPushButtonWidgetClass, one, NULL );
  XtVaCreateManagedWidget("Four", xmPushButtonWidgetClass, one, NULL );

  XtAddCallback(one, XmNactivateCallback, (XtCallbackProc)Activate, (XtPointer)NULL);

  XtManageChild(one);
  XtManageChild(rc);
  XtManageChild(scrollWind);

  XtRealizeWidget(toplevel);
  XtAppMainLoop(app);

  exit(0);
}
