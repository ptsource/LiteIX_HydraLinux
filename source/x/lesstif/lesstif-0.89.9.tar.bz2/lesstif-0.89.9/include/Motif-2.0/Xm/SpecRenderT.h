/**
 *
 * $Header: /cvsroot/hungry/lesstif/include/Motif-2.0/Xm/SpecRenderT.h,v 1.2 1999/08/13 13:18:23 danny Exp $
 *
 * Copyright (C) 1999 Free Software Foundation, Inc.
 *
 * This file is part of the GNU LessTif Library.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 **/


#ifndef XM_SPEC_RENDER_T_H
#define XM_SPEC_RENDER_T_H

#include <X11/Intrinsic.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef XmRenderTable (*XmSpecRenderGetTableProc)(Widget, XtEnum);

typedef struct {
	int				version;
	XmSpecRenderGetTableProc	getRenderTable;
} XmSpecRenderTraitRec, *XmSpecRenderTrait;

extern XrmQuark	XmQTspecifyRenderTable;

#ifdef __cplusplus
}
#endif

#endif /* XM_SPEC_RENDER_T_H */

