/**
 * 
 * $Header: /cvsroot/hungry/lesstif/include/Motif-2.0/Xm/SpinB.h,v 1.3 1997/08/25 13:05:09 u27113 Exp $
 *
 * Copyright (C) 1997 Free Software Foundation, Inc.
 *
 * This file is part of the GNU LessTif Library.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 **/

#ifndef XM_SPINB_H
#define XM_SPINB_H

#include <Xm/Xm.h>

#ifdef __cplusplus
extern "C" {
#endif

extern WidgetClass xmSpinBoxWidgetClass;

typedef struct _XmSpinBoxClassRec *XmSpinBoxWidgetClass;
typedef struct _XmSpinBoxRec *XmSpinBoxWidget;

#ifndef XmIsSpinBox
#define XmIsSpinBox(w) XtIsSubclass((w), xmSpinBoxWidgetClass)
#endif

extern Widget XmCreateSpinBox(Widget parent, char *name, ArgList arglist, Cardinal argcount);

#ifdef __cplusplus
}
#endif

#endif /* XM_SPINB_H */

