/**
 * 
 * $Id: Container.h,v 1.1 1997/07/08 17:04:09 miers Exp $
 *
 * Copyright (C) 1997 Free Software Foundation, Inc.
 *
 * This file is part of the GNU LessTif Library.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 **/

#ifndef XM_CONTAINER_H
#define XM_CONTAINER_H

#include <Xm/Xm.h>

#ifdef __cplusplus
extern "C" {
#endif

extern WidgetClass xmContainerWidgetClass;

typedef struct _XmContainerRec *XmContainerWidget;
typedef struct _XmContainerClassRec *XmContainerWidgetClass;

#ifndef XmIsContainer
#define XmIsContainer(w) XtIsSubclass(w, xmContainerWidgetClass)
#endif

Widget XmCreateContainer(Widget parent,
                         String name,
                         ArgList arglist,
                         Cardinal argcount);
int XmContainerGetItemChildren(Widget w, 
                               Widget item,
                               WidgetList *item_children);
void XmContainerRelayout(Widget w);
void XmContainerReorder(Widget w, WidgetList cwid_list, int cwid_count);
Boolean XmContainerCut(Widget w, Time timestamp);
Boolean XmContainerCopy(Widget w, Time timestamp);
Boolean XmContainerPaste(Widget w);
Boolean XmContainerCopyLink(Widget w, Time timestamp);
Boolean XmContainerPasteLink(Widget w);

#ifdef __cplusplus
}
#endif

#endif

