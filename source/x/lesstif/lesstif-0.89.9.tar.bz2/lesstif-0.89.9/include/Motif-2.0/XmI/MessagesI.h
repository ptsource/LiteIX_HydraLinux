/**
 *
 * Copyright (C) 1997 Peter G. Williams, and Others
 *
 * This file is part of the GNU LessTif Library.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 **/


#ifndef XM_MESSAGES_I_H
#define XM_MESSAGES_I_H

#ifdef __cplusplus
extern "C" {
#endif

extern _XmConst char * XME_WARNING;
extern _XmConst char * _XmMsgBaseClass_0000;
extern _XmConst char * _XmMsgBaseClass_0001;
extern _XmConst char * _XmMsgBaseClass_0002;
extern _XmConst char * _XmMsgBulletinB_0001;
extern _XmConst char * _XmMsgCSText_0000;
extern _XmConst char * _XmMsgCSText_0001;
extern _XmConst char * _XmMsgCSText_0002;
extern _XmConst char * _XmMsgCSText_0003;
extern _XmConst char * _XmMsgCSText_0004;
extern _XmConst char * _XmMsgCSText_0005;
extern _XmConst char * _XmMsgCSText_0006;
extern _XmConst char * _XmMsgCSText_0007;
extern _XmConst char * _XmMsgCascadeB_0000;
extern _XmConst char * _XmMsgCascadeB_0001;
extern _XmConst char * _XmMsgCascadeB_0002;
extern _XmConst char * _XmMsgCascadeB_0003;
extern _XmConst char * _XmMsgComboBox_0000;
extern _XmConst char * _XmMsgComboBox_0001;
extern _XmConst char * _XmMsgComboBox_0002;
extern _XmConst char * _XmMsgComboBox_0003;
extern _XmConst char * _XmMsgComboBox_0004;
extern _XmConst char * _XmMsgComboBox_0005;
extern _XmConst char * _XmMsgComboBox_0006;
extern _XmConst char * _XmMsgComboBox_0007;
extern _XmConst char * _XmMsgComboBox_0008;
extern _XmConst char * _XmMsgCommand_0000;
extern _XmConst char * _XmMsgCommand_0001;
extern _XmConst char * _XmMsgCommand_0002;
extern _XmConst char * _XmMsgCommand_0003;
extern _XmConst char * _XmMsgCommand_0004;
extern _XmConst char * _XmMsgCommand_0005;
extern _XmConst char * _XmMsgContainer_0000;
extern _XmConst char * _XmMsgCutPaste_0000;
extern _XmConst char * _XmMsgCutPaste_0001;
extern _XmConst char * _XmMsgCutPaste_0002;
extern _XmConst char * _XmMsgCutPaste_0003;
extern _XmConst char * _XmMsgCutPaste_0004;
extern _XmConst char * _XmMsgCutPaste_0005;
extern _XmConst char * _XmMsgCutPaste_0006;
extern _XmConst char * _XmMsgCutPaste_0007;
extern _XmConst char * _XmMsgCutPaste_0008;
extern _XmConst char * _XmMsgCutPaste_0009;
extern _XmConst char * _XmMsgDialogS_0000;
extern _XmConst char * _XmMsgDisplay_0001;
extern _XmConst char * _XmMsgDisplay_0002;
extern _XmConst char * _XmMsgDisplay_0003;
extern _XmConst char * _XmMsgDragBS_0000;
extern _XmConst char * _XmMsgDragBS_0001;
extern _XmConst char * _XmMsgDragBS_0002;
extern _XmConst char * _XmMsgDragBS_0003;
extern _XmConst char * _XmMsgDragBS_0004;
extern _XmConst char * _XmMsgDragBS_0005;
extern _XmConst char * _XmMsgDragBS_0006;
extern _XmConst char * _XmMsgDragC_0001;
extern _XmConst char * _XmMsgDragC_0002;
extern _XmConst char * _XmMsgDragC_0003;
extern _XmConst char * _XmMsgDragC_0004;
extern _XmConst char * _XmMsgDragC_0005;
extern _XmConst char * _XmMsgDragC_0006;
extern _XmConst char * _XmMsgDragICC_0000;
extern _XmConst char * _XmMsgDragICC_0001;
extern _XmConst char * _XmMsgDragIcon_0000;
extern _XmConst char * _XmMsgDragIcon_0001;
extern _XmConst char * _XmMsgDragIcon_0002;
extern _XmConst char * _XmMsgDragOverS_0000;
extern _XmConst char * _XmMsgDragOverS_0001;
extern _XmConst char * _XmMsgDragOverS_0002;
extern _XmConst char * _XmMsgDragOverS_0003;
extern _XmConst char * _XmMsgDragUnder_0000;
extern _XmConst char * _XmMsgDragUnder_0001;
extern _XmConst char * _XmMsgDropSMgrI_0001;
extern _XmConst char * _XmMsgDropSMgrI_0002;
extern _XmConst char * _XmMsgDropSMgrI_0003;
extern _XmConst char * _XmMsgDropSMgr_0001;
extern _XmConst char * _XmMsgDropSMgr_0002;
extern _XmConst char * _XmMsgDropSMgr_0003;
extern _XmConst char * _XmMsgDropSMgr_0004;
extern _XmConst char * _XmMsgDropSMgr_0005;
extern _XmConst char * _XmMsgDropSMgr_0006;
extern _XmConst char * _XmMsgDropSMgr_0007;
extern _XmConst char * _XmMsgDropSMgr_0008;
extern _XmConst char * _XmMsgDropSMgr_0009;
extern _XmConst char * _XmMsgDropSMgr_0010;
extern _XmConst char * _XmMsgForm_0000;
extern _XmConst char * _XmMsgForm_0002;
extern _XmConst char * _XmMsgForm_0003;
extern _XmConst char * _XmMsgForm_0004;
extern _XmConst char * _XmMsgGadget_0000;
extern _XmConst char * _XmMsgGeoUtils_0000;
extern _XmConst char * _XmMsgGeoUtils_0001;
extern _XmConst char * _XmMsgGeoUtils_0002;
extern _XmConst char * _XmMsgGetSecRes_0000;
extern _XmConst char * _XmMsgGrabS_0000;
extern _XmConst char * _XmMsgLabel_0003;
extern _XmConst char * _XmMsgLabel_0004;
extern _XmConst char * _XmMsgList_0000;
extern _XmConst char * _XmMsgList_0005;
extern _XmConst char * _XmMsgList_0006;
extern _XmConst char * _XmMsgList_0007;
extern _XmConst char * _XmMsgList_0008;
extern _XmConst char * _XmMsgList_0009;
extern _XmConst char * _XmMsgList_0010;
extern _XmConst char * _XmMsgList_0011;
extern _XmConst char * _XmMsgList_0012;
extern _XmConst char * _XmMsgList_0013;
extern _XmConst char * _XmMsgList_0014;
extern _XmConst char * _XmMsgList_0015;
extern _XmConst char * _XmMsgMainW_0000;
extern _XmConst char * _XmMsgMainW_0001;
extern _XmConst char * _XmMsgManager_0000;
extern _XmConst char * _XmMsgManager_0001;
extern _XmConst char * _XmMsgMenuShell_0000;
extern _XmConst char * _XmMsgMenuShell_0001;
extern _XmConst char * _XmMsgMenuShell_0002;
extern _XmConst char * _XmMsgMenuShell_0003;
extern _XmConst char * _XmMsgMenuShell_0004;
extern _XmConst char * _XmMsgMenuShell_0005;
extern _XmConst char * _XmMsgMenuShell_0006;
extern _XmConst char * _XmMsgMenuShell_0007;
extern _XmConst char * _XmMsgMenuShell_0008;
extern _XmConst char * _XmMsgMenuShell_0009;
extern _XmConst char * _XmMsgMessageB_0003;
extern _XmConst char * _XmMsgMessageB_0004;
extern _XmConst char * _XmMsgMotif_0000;
extern _XmConst char * _XmMsgMotif_0001;
extern _XmConst char * _XmMsgNavigMap_0000;
extern _XmConst char * _XmMsgNotebook_0000;
extern _XmConst char * _XmMsgPanedW_0000;
extern _XmConst char * _XmMsgPanedW_0001;
extern _XmConst char * _XmMsgPanedW_0002;
extern _XmConst char * _XmMsgPanedW_0003;
extern _XmConst char * _XmMsgPanedW_0004;
extern _XmConst char * _XmMsgPanedW_0005;
extern _XmConst char * _XmMsgPixConv_0000;
extern _XmConst char * _XmMsgPrimitive_0000;
extern _XmConst char * _XmMsgProtocols_0000;
extern _XmConst char * _XmMsgProtocols_0001;
extern _XmConst char * _XmMsgProtocols_0002;
extern _XmConst char * _XmMsgRegion_0000;
extern _XmConst char * _XmMsgRepType_0001;
extern _XmConst char * _XmMsgRepType_0002;
extern _XmConst char * _XmMsgResConvert_0000;
extern _XmConst char * _XmMsgResConvert_0001;
extern _XmConst char * _XmMsgResConvert_0002;
extern _XmConst char * _XmMsgResConvert_0003;
extern _XmConst char * _XmMsgResConvert_0004;
extern _XmConst char * _XmMsgResConvert_0005;
extern _XmConst char * _XmMsgResConvert_0006;
extern _XmConst char * _XmMsgResConvert_0007;
extern _XmConst char * _XmMsgResConvert_0008;
extern _XmConst char * _XmMsgResConvert_0009;
extern _XmConst char * _XmMsgResConvert_0010;
extern _XmConst char * _XmMsgResConvert_0011;
extern _XmConst char * _XmMsgResConvert_0012;
extern _XmConst char * _XmMsgResConvert_0013;
extern _XmConst char * _XmMsgResConvert_0014;
extern _XmConst char * _XmMsgResConvert_0015;
extern _XmConst char * _XmMsgResConvert_0016;
extern _XmConst char * _XmMsgRowColText_0024;
extern _XmConst char * _XmMsgRowColumn_0000;
extern _XmConst char * _XmMsgRowColumn_0001;
extern _XmConst char * _XmMsgRowColumn_0002;
extern _XmConst char * _XmMsgRowColumn_0003;
extern _XmConst char * _XmMsgRowColumn_0004;
extern _XmConst char * _XmMsgRowColumn_0005;
extern _XmConst char * _XmMsgRowColumn_0007;
extern _XmConst char * _XmMsgRowColumn_0008;
extern _XmConst char * _XmMsgRowColumn_0015;
extern _XmConst char * _XmMsgRowColumn_0016;
extern _XmConst char * _XmMsgRowColumn_0017;
extern _XmConst char * _XmMsgRowColumn_0018;
extern _XmConst char * _XmMsgRowColumn_0019;
extern _XmConst char * _XmMsgRowColumn_0020;
extern _XmConst char * _XmMsgRowColumn_0022;
extern _XmConst char * _XmMsgRowColumn_0023;
extern _XmConst char * _XmMsgRowColumn_0025;
extern _XmConst char * _XmMsgRowColumn_0026;
extern _XmConst char * _XmMsgRowColumn_0027;
extern _XmConst char * _XmMsgScaleScrBar_0004;
extern _XmConst char * _XmMsgScale_0000;
extern _XmConst char * _XmMsgScale_0001;
extern _XmConst char * _XmMsgScale_0002;
extern _XmConst char * _XmMsgScale_0005;
extern _XmConst char * _XmMsgScale_0006;
extern _XmConst char * _XmMsgScale_0007;
extern _XmConst char * _XmMsgScale_0008;
extern _XmConst char * _XmMsgScale_0009;
extern _XmConst char * _XmMsgScreen_0000;
extern _XmConst char * _XmMsgScreen_0001;
extern _XmConst char * _XmMsgScrollBar_0000;
extern _XmConst char * _XmMsgScrollBar_0001;
extern _XmConst char * _XmMsgScrollBar_0002;
extern _XmConst char * _XmMsgScrollBar_0003;
extern _XmConst char * _XmMsgScrollBar_0004;
extern _XmConst char * _XmMsgScrollBar_0005;
extern _XmConst char * _XmMsgScrollBar_0006;
extern _XmConst char * _XmMsgScrollBar_0007;
extern _XmConst char * _XmMsgScrollBar_0008;
extern _XmConst char * _XmMsgScrollFrameT_0000;
extern _XmConst char * _XmMsgScrollFrameT_0001;
extern _XmConst char * _XmMsgScrollVis_0000;
extern _XmConst char * _XmMsgScrolledW_0004;
extern _XmConst char * _XmMsgScrolledW_0005;
extern _XmConst char * _XmMsgScrolledW_0006;
extern _XmConst char * _XmMsgScrolledW_0007;
extern _XmConst char * _XmMsgScrolledW_0008;
extern _XmConst char * _XmMsgScrolledW_0009;
extern _XmConst char * _XmMsgSelectioB_0001;
extern _XmConst char * _XmMsgSelectioB_0002;
extern _XmConst char * _XmMsgSpinB_0001;
extern _XmConst char * _XmMsgSpinB_0002;
extern _XmConst char * _XmMsgSpinB_0003;
extern _XmConst char * _XmMsgSpinB_0004;
extern _XmConst char * _XmMsgSpinB_0005;
extern _XmConst char * _XmMsgSpinB_0006;
extern _XmConst char * _XmMsgSpinB_0007;
extern _XmConst char * _XmMsgTextFWcs_0000;
extern _XmConst char * _XmMsgTextFWcs_0001;
extern _XmConst char * _XmMsgTextF_0000;
extern _XmConst char * _XmMsgTextF_0001;
extern _XmConst char * _XmMsgTextF_0002;
extern _XmConst char * _XmMsgTextF_0003;
extern _XmConst char * _XmMsgTextF_0004;
extern _XmConst char * _XmMsgTextF_0005;
extern _XmConst char * _XmMsgTextF_0006;
extern _XmConst char * _XmMsgTextIn_0000;
extern _XmConst char * _XmMsgTextOut_0000;
extern _XmConst char * _XmMsgText_0000;
extern _XmConst char * _XmMsgText_0002;
extern _XmConst char * _XmMsgTransfer_0000;
extern _XmConst char * _XmMsgTransfer_0001;
extern _XmConst char * _XmMsgTransfer_0002;
extern _XmConst char * _XmMsgTransfer_0003;
extern _XmConst char * _XmMsgTransfer_0004;
extern _XmConst char * _XmMsgTransfer_0005;
extern _XmConst char * _XmMsgTransfer_0006;
extern _XmConst char * _XmMsgTransfer_0007;
extern _XmConst char * _XmMsgVaSimple_0000;
extern _XmConst char * _XmMsgVaSimple_0001;
extern _XmConst char * _XmMsgVaSimple_0002;
extern _XmConst char * _XmMsgVendorE_0000;
extern _XmConst char * _XmMsgVendorE_0005;
extern _XmConst char * _XmMsgVendor_0000;
extern _XmConst char * _XmMsgVendor_0001;
extern _XmConst char * _XmMsgVendor_0002;
extern _XmConst char * _XmMsgVendor_0003;
extern _XmConst char * _XmMsgVisual_0000;
extern _XmConst char * _XmMsgVisual_0001;
extern _XmConst char * _XmMsgVisual_0002;
extern _XmConst char * _XmMsgXmIm_0000;
extern _XmConst char * _XmMsgXmRenderT_0000;
extern _XmConst char * _XmMsgXmRenderT_0001;
extern _XmConst char * _XmMsgXmRenderT_0002;
extern _XmConst char * _XmMsgXmRenderT_0003;
extern _XmConst char * _XmMsgXmRenderT_0004;
extern _XmConst char * _XmMsgXmRenderT_0005;
extern _XmConst char * _XmMsgXmSelect_0000;
extern _XmConst char * _XmMsgXmSelect_0001;
extern _XmConst char * _XmMsgXmSelect_0002;
extern _XmConst char * _XmMsgXmString_0000;
extern _XmConst char * _XmMsgXmTabList_0000;

#ifdef __cplusplus
}
#endif

#endif /* XM_MESSAGES_I_H */

