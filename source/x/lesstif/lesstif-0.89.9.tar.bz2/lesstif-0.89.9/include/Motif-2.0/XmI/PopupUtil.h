/**
 *
 * $Id: PopupUtil.h,v 1.2 1999/01/28 21:04:48 pgw Exp $
 *
 * Copyright (C) 1998 Free Software Foundation, Inc.
 *
 * This file is part of the GNU LessTif Library.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 **/

#ifndef XM_POPUPUTIL_H
#define XM_POPUPUTIL_H

#ifdef __cplusplus
extern "C" {
#endif

/*
  These should be used instead of there Xt alternative.
*/
void _XmPopup(Widget w, XtGrabKind kind);
void _XmPopupSpringLoaded(Widget w);
void _XmPopdown(Widget w);

#ifdef __cplusplus
}
#endif

#endif

