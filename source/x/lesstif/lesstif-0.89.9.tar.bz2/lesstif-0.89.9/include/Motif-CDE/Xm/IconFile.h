/**
 *
 * $Id: IconFile.h,v 1.1 1997/11/15 21:24:03 miers Exp $
 * 
 * Copyright (C) 1995 Free Software Foundation, Inc.
 *
 * This file is part of the GNU LessTif Library.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 **/
#ifndef ICON_FILE_H
#define ICON_FILE_H

#include <Xm/Xm.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * values for icon magnitude
 */
#define XmUNSPECIFIED_ICON_SIZE 0
#define XmLARGE_ICON_SIZE       1
#define XmMEDIUM_ICON_SIZE      2
#define XmSMALL_ICON_SIZE       3
#define XmTINY_ICON_SIZE        4


extern String XmGetIconFileName(Screen *screen,
				String imageInstanceName,
				String imageClassName,
				String hostPrefix,
				unsigned int size);
#ifdef __cplusplus
}
#endif

#endif /* ICON_FILE_H */
