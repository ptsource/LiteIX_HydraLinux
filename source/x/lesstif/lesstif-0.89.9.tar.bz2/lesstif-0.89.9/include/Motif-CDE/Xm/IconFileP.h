/**
 *
 * $Id: IconFileP.h,v 1.1 1997/11/15 21:24:04 miers Exp $
 * 
 * Copyright (C) 1995 Free Software Foundation, Inc.
 *
 * This file is part of the GNU LessTif Library.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 **/
#ifndef ICON_FILEP_H
#define ICON_FILEP_H

#include "IconFile.h"

#ifdef __cplusplus
extern "C"
{
#endif

/*
 * referenced in InitPath strings and in the files 
 * that uses it (ImageCache.c and Mrmhier.c)
 */
#define MATCH_CHAR 'P'

extern void XmeFlushIconFileCache(String path);

extern void _XmOSGenerateMaskName(String imageName, String maskNameBuf);

#ifdef __cplusplus
}
#endif

#endif /* ICON_FILEP_H */
