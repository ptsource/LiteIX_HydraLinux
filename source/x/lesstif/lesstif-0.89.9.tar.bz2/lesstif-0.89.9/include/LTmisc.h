/*
 * $Id: LTmisc.h,v 1.2 1998/09/02 19:22:42 danny Exp $
 * 
 * Copyright (C) 1998 Free Software Foundation, Inc.
 *
 * This file is part of the GNU LessTif Library.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 **/

#ifndef	HAVE_STRCASECMP
#ifdef	strcasecmp
#undef	strcasecmp
#endif
int strcasecmp(char *, char *);
#endif

#ifndef	HAVE_STRNCASECMP
#ifdef	strncasecmp
#undef	strncasecmp
#endif
int strncasecmp(char *, char *, int);
#endif

#ifndef	HAVE_STRSTR
#ifdef	strstr
#undef	strstr
#endif
char *strstr(char *, char *);
#endif

#ifndef	HAVE_MEMMOVE
#ifdef	memmove
#undef	memmove
#endif
void *memmove(void *, void *, size_t);
#endif
