/* $XConsortium: Printstr.h /main/2 1996/11/16 15:20:15 rws $ */
/******************************************************************************
 ******************************************************************************
 **
 ** File:         Printstr.h
 **
 ** Description: Definitions needed by the server and library, but
 **              not clients.
 **
 **              Print.h for server, library and clients.
 **
 ******************************************************************************
 **
 ** (c) Copyright 1996 Hewlett-Packard Company
 ** (c) Copyright 1996 International Business Machines Corp.
 ** (c) Copyright 1996 Sun Microsystems, Inc.
 ** (c) Copyright 1996 Novell, Inc.
 ** (c) Copyright 1996 Digital Equipment Corp.
 ** (c) Copyright 1996 Fujitsu Limited
 ** (c) Copyright 1996 Hitachi, Ltd.
 ** 
 ** Permission is hereby granted, free of charge, to any person obtaining a copy
 ** of this software and associated documentation files (the "Software"), to deal
 ** in the Software without restriction, including without limitation the rights
 ** to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 ** copies of the Software, and to permit persons to whom the Software is
 ** furnished to do so, subject to the following conditions:
 **
 ** The above copyright notice and this permission notice shall be included in
 ** all copies or substantial portions of the Software.
 **
 ** THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 ** IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 ** FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
 ** COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 ** IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 ** CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 **
 ** Except as contained in this notice, the names of the copyright holders shall
 ** not be used in advertising or otherwise to promote the sale, use or other
 ** dealings in this Software without prior written authorization from said
 ** copyright holders.
 **
 ******************************************************************************
 *****************************************************************************/


#ifndef _XpPrintstr_H_
#define _XpPrintstr_H_

/*
 * NEED_EVENTS and NEED_REPLIES are hacks to limit the linker symbol-table
 * size.   When function prototypes are needed from Print.h, this sets up
 * a cascading dependency on Printstr.h and eventually Xproto.h to provide
 * the event and reply struct definitions.
 */
#ifndef NEED_EVENTS
#define NEED_EVENTS
#endif /* NEED_EVENTS */

#define NEED_REPLIES

#include <X11/Xproto.h>
#ifndef _XP_PRINT_SERVER_
#include <X11/Xlib.h>
#endif /* _XP_PRINT_SERVER_ */

/*
 * Pull in other definitions.  Print.h will hide some things if we're
 * doing server side work.
 */
#include <X11/extensions/Print.h>

#include <X11/Xfuncproto.h>

_XFUNCPROTOBEGIN

/******************************************************************************
 *
 * Protocol requests constants and alignment values
 *
 * Note: Xlib macro's expect X_ABC where ABC is the name of the
 * protocol request.
 */
#define X_PrintQueryVersion		0
#define X_PrintGetPrinterList		1
#define X_PrintCreateContext		2
#define X_PrintSetContext		3
#define X_PrintGetContext		4
#define X_PrintDestroyContext		5
#define X_PrintGetContextScreen		6
#define X_PrintStartJob			7
#define X_PrintEndJob			8
#define X_PrintStartDoc			9
#define X_PrintEndDoc			10
#define X_PrintPutDocumentData		11
#define X_PrintGetDocumentData		12
#define X_PrintStartPage		13
#define X_PrintEndPage			14
#define X_PrintSelectInput		15
#define X_PrintInputSelected		16
#define X_PrintGetAttributes		17
#define X_PrintSetAttributes		18
#define X_PrintGetOneAttribute		19
#define X_PrintRehashPrinterList	20
#define X_PrintGetPageDimensions	21
#define X_PrintQueryScreens		22
#define X_PrintSetImageResolution	23
#define X_PrintGetImageResolution	24

/********************************************************************
 *
 * Protocol data types
 */
#define PCONTEXT CARD32
#define WINDOW   CARD32
#define DRAWABLE CARD32
#define BITMASK  CARD32

/******************************************************************************
 *
 * Event wire struct definitions
 *
 * Note: Xlib macro's expect xABC struct names and sz_xABC size
 * constants where ABC is the name of the protocol request.
 */


/*********************************************************************
 *
 * Events.
 *
 * See Print.h for the protocol "type" values.
 */
typedef struct _xPrintPrintEvent {
	BYTE type;		/* XPPrintNotify + extEntry->eventBase */
	BYTE detail;		/* XPStartJobNotify, XPEndJobNotify,
				   XPStartDocNotify, XPEndDocNotify,
				   XPStartPageNotify, XPEndPageNotify */
	CARD16 sequenceNumber B16;
	PCONTEXT printContext B32; /* print context */
	BOOL   cancel;		/* canceled flag */
	CARD8  pad1;		/* rest is unused */
	CARD16 pad2 B16;
	CARD32 pad3 B32;
	CARD32 pad4 B32;
	CARD32 pad5 B32;
	CARD32 pad6 B32;
	CARD32 pad7 B32;
} xPrintPrintEvent;
#define sz_xPrintPrintEvent 32;

typedef struct _xPrintAttributeEvent {
	BYTE   type;		/* XPAttributeNotify + extEntry->eventBase */
	BYTE   detail;		/* XPJobAttr, XPDocAttr, XPPageAttr,
				   XPPrinterAttr, XPSpoolerAttr,
				   XPMediumAttr, XPServerAttr */
	CARD16 sequenceNumber B16;
	PCONTEXT printContext B32; /* print context */
	CARD32 pad1 B32;
	CARD32 pad2 B32;
	CARD32 pad3 B32;
	CARD32 pad4 B32;
	CARD32 pad5 B32;
	CARD32 pad6 B32;
} xPrintAttributeEvent;
#define sz_xPrintAttributeEvent 32;


/*********************************************************************
 *
 * Requests
 */
typedef struct _PrintQueryVersion {
	CARD8	reqType;		/* always PrintReqCode */
	CARD8	printReqType;		/* always X_PrintQueryVersion */
	CARD16	length B16;
} xPrintQueryVersionReq;
#define sz_xPrintQueryVersionReq	4

typedef struct {
	BYTE	type;			/* X_Reply */
	CARD8	unused;			/* not used */
	CARD16	sequenceNumber B16;
	CARD32	length B32;
	CARD16	majorVersion B16;	/* major version of Xp protocol */
	CARD16	minorVersion B16;	/* minor version of Xp protocol */
	CARD32	pad1 B32;
	CARD32	pad2 B32;
	CARD32	pad3 B32;
	CARD32	pad4 B32;
	CARD32	pad5 B32;
} xPrintQueryVersionReply;
#define sz_xPrintQueryVersionReply	32


typedef struct _PrintGetPrinterList {
	CARD8	reqType;		/* always PrintReqCode */
	CARD8	printReqType;		/* always X_PrintGetPrinterList */
	CARD16	length B16;
	CARD32	printerNameLen B32;	/* length of printer name */
	CARD32	localeLen B32;		/* length of locale string */

	/* variable portion *****************************************
	STRING8	printerName;		 * printer name *
	BYTE	pad(printerNameLen)	 * unused *
	STRING8	locale;			 * locale *
	BYTE	pad(localeLen)		 * unused *
	************************************************************/
} xPrintGetPrinterListReq;
#define sz_xPrintGetPrinterListReq	12

typedef struct {
	BYTE	type;			/* X_Reply */
	CARD8	unused;			/* not used */
	CARD16	sequenceNumber B16;
	CARD32	length B32;
	CARD32	listCount B32;		/* of PRINTER recs below */
	CARD32	pad1 B32;
	CARD32	pad2 B32;
	CARD32	pad3 B32;
	CARD32	pad4 B32;
	CARD32	pad5 B32;

	/* variable portion *****************************************
	CARD32	nameLen B32;		* length of name in bytes *
	STRING8	name;			* name *
	BYTE	pad(nameLen)		* unused *

	CARD32	descLen B32;		* length of desc in bytes *
	STRING8	desc;			* localized description *
	BYTE	pad(descLen)		* unused *
	************************************************************/
} xPrintGetPrinterListReply;
#define sz_xPrintGetPrinterListReply	32


typedef struct _PrintRehashPrinterList {
	CARD8	reqType;		/* always PrintReqCode */
	CARD8	printReqType;		/* always X_PrintRehashPrinterList */
	CARD16	length B16;
} xPrintRehashPrinterListReq;
#define sz_xPrintRehashPrinterListReq	4


typedef struct _PrintCreateContext {
	CARD8	reqType;		/* always PrintReqCode */
	CARD8	printReqType;		/* always X_PrintInitSetContext */
	CARD16	length B16;
	CARD32	contextID B32;		/* ID for context */
	CARD32	printerNameLen B32;	/* length of printerName in bytes */
	CARD32	localeLen B32;		/* length of locale in bytes */

	/* variable portion *****************************************
	STRING8	printerName		 * printer name *
	BYTE	pad(printerNameLen)	 * unused *
	STRING8	locale			 * locale *
	BYTE	pad(locale)		 * unused *
	************************************************************/
} xPrintCreateContextReq;		
#define sz_xPrintCreateContextReq	16


typedef struct _PrintSetContext {
	CARD8	reqType;		/* always PrintReqCode */
	CARD8	printReqType;		/* always X_PrintSetContext */
	CARD16	length B16;
	PCONTEXT printContext B32;	/* print context */
} xPrintSetContextReq;		
#define sz_xPrintSetContextReq		8


typedef struct _PrintGetContext {
	CARD8	reqType;		/* always PrintReqCode */
	CARD8	printReqType;		/* always X_PrintGetContext */
	CARD16	length B16;
} xPrintGetContextReq;		
#define sz_xPrintGetContextReq		4

typedef struct {
	BYTE	type;			/* X_Reply */
	CARD8	unused;			/* not used */
	CARD16	sequenceNumber B16;
	CARD32	length B32;
	PCONTEXT printContext B32;	/* print context */
	CARD32	pad1 B32;
	CARD32	pad2 B32;
	CARD32	pad3 B32;
	CARD32	pad4 B32;
	CARD32	pad5 B32;
} xPrintGetContextReply;
#define sz_xPrintGetContextReply	32


typedef struct _PrintDestroyContext {
	CARD8	reqType;		/* always PrintReqCode */
	CARD8	printReqType;		/* always X_PrintDestroyContext */
	CARD16	length B16;
	PCONTEXT printContext B32;	/* print context */
} xPrintDestroyContextReq;		
#define sz_xPrintDestroyContextReq	8


typedef struct _PrintGetContextScreen {
	CARD8	reqType;		/* always PrintReqCode */
	CARD8	printReqType;		/* always X_PrintGetContextScreen */
	CARD16	length B16;
	PCONTEXT printContext B32;	/* print context */
} xPrintGetContextScreenReq;		
#define sz_xPrintGetContextScreenReq	8

typedef struct {
	BYTE	type;			/* X_Reply */
	CARD8	unused;			/* not used */
	CARD16	sequenceNumber B16;
	CARD32	length B32;
	WINDOW  rootWindow;		/* screenPtr represented as rootWin */
	CARD32	pad1 B32;
	CARD32	pad2 B32;
	CARD32	pad3 B32;
	CARD32	pad4 B32;
	CARD32	pad5 B32;
} xPrintGetContextScreenReply;
#define sz_xPrintGetContextScreenReply	32


typedef struct _PrintStartJob {
	CARD8	reqType;		/* always PrintReqCode */
	CARD8	printReqType;		/* always X_PrintStartJob */
	CARD16	length B16;
	CARD8	saveData;		/* save data boolean */
	CARD8	pad1;
	CARD16	pad2 B16;
} xPrintStartJobReq;		
#define sz_xPrintStartJobReq		8

typedef struct _PrintEndJob {
	CARD8	reqType;		/* always PrintReqCode */
	CARD8	printReqType;		/* always X_PrintEndJob */
	CARD16	length B16;
	BOOL	cancel;			/* cancel boolean */
	CARD8	pad1;
	CARD16	pad2 B16;
} xPrintEndJobReq;
#define sz_xPrintEndJobReq		8


typedef struct _PrintStartDoc {
	CARD8	reqType;		/* always PrintReqCode */
	CARD8	printReqType;		/* always X_PrintStartDoc */
	CARD16	length B16;
	CARD8	type;			/* type for document */
	CARD8	pad1;
	CARD16	pad2 B16;
} xPrintStartDocReq;		
#define sz_xPrintStartDocReq		8

typedef struct _PrintEndDoc {
	CARD8	reqType;		/* always PrintReqCode */
	CARD8	printReqType;		/* always X_PrintEndDoc */
	CARD16	length B16;
	BOOL	cancel;			/* cancel boolean */
	CARD8	pad1;
	CARD16	pad2 B16;
} xPrintEndDocReq;
#define sz_xPrintEndDocReq		8


typedef struct _PrintPutDocumentData {
	CARD8	reqType;		/* always PrintReqCode */
	CARD8	printReqType;		/* always X_PrintPutDocumentData */
	CARD16	length B16;
	DRAWABLE drawable B32;		/* target drawable */
	CARD32	len_data B32;		/* big len in bytes */
	CARD16	len_fmt;		/* len in bytes */
	CARD16	len_options;		/* len in bytes */

	/* variable portion *****************************************
	LISTofBYTE	data;		 * data *
	BYTE		pad(len_data)	 * unused *
	STRING8		doc_fmt;	 * ISO compliant desc of data type *
	BYTE		pad(len_fmt)	 * unused *
	STRING8		options;	 * additional device-dependent desc *
	BYTE		pad(len_options) * unused *
	************************************************************/
} xPrintPutDocumentDataReq;
#define sz_xPrintPutDocumentDataReq	16


typedef struct _PrintGetDocumentData {
	CARD8	reqType;		/* always PrintReqCode */
	CARD8	printReqType;		/* always X_PrintGetDocumentData */
	CARD16	length B16;
	PCONTEXT printContext B32;	/* print context */
	CARD32	maxBufferSize B32;	/* maximum buffer size requested */
} xPrintGetDocumentDataReq;		
#define sz_xPrintGetDocumentDataReq	12

typedef struct {
	BYTE	type;			/* X_Reply */
	CARD8	unused;			/* not used */
	CARD16	sequenceNumber B16;
	CARD32	length B32;
	CARD32	statusCode B32;		/* status code for reply */
	CARD32	finishedFlag B32;	/* is this the last reply */
	CARD32	dataLen B32;		/* data length */
	CARD32	pad1 B32;
	CARD32	pad2 B32;
	CARD32	pad3 B32;

	/* variable portion *****************************************
	LISTofBYTE	data;		 * data *
	BYTE		pad(count)	 * unused *
	************************************************************/
} xPrintGetDocumentDataReply;
#define sz_xPrintGetDocumentDataReply	32


typedef struct _PrintStartPage {
	CARD8	reqType;		/* always PrintReqCode */
	CARD8	printReqType;		/* always X_PrintStartPage */
	CARD16	length B16;
	WINDOW	window B32;		/* window */
} xPrintStartPageReq;		
#define sz_xPrintStartPageReq		8

typedef struct _PrintEndPage {
	CARD8	reqType;		/* always PrintReqCode */
	CARD8	printReqType;		/* always X_PrintEndPage */
	CARD16	length B16;
	BOOL	cancel;			/* cancel boolean */
	CARD8	pad1;
	CARD16	pad2 B16;
} xPrintEndPageReq;
#define sz_xPrintEndPageReq		8


typedef struct _PrintSelectInput {
        CARD8   reqType;        	/* always PrintReqCode */
	CARD8   printReqType;		/* always X_PrintSelectInput */
	CARD16	length B16;
	PCONTEXT printContext B32;	/* print context */
	BITMASK	eventMask B32;
} xPrintSelectInputReq;
#define sz_xPrintSelectInputReq		12


typedef struct _PrintInputSelected {
        CARD8   reqType;        	/* always PrintReqCode */
	CARD8   printReqType;		/* always X_PrintInputSelected */
	CARD16	length B16;
	PCONTEXT printContext B32;	/* print context */
} xPrintInputSelectedReq;
#define sz_xPrintInputSelectedReq	8

typedef struct {
	BYTE	type;			/* X_Reply */
	CARD8	unused;			/* not used */
	CARD16	sequenceNumber B16;
	CARD32	length B32;
	BITMASK	eventMask B32;		/* your event mask */
	BITMASK	allEventsMask B32;	/* all event mask */
	CARD32	pad1 B32;
	CARD32	pad2 B32;
	CARD32	pad3 B32;
	CARD32	pad4 B32;
} xPrintInputSelectedReply;
#define sz_xPrintInputSelectedReply	32

typedef struct _PrintGetAttributes {
        CARD8   reqType;        	/* always PrintReqCode */
	CARD8   printReqType;		/* always X_PrintGetAttributes */
	CARD16	length B16;
	PCONTEXT printContext B32;	/* print context */
        CARD8   type;			/* type */
        CARD8   pad1;			/* unused */
        CARD16  pad2 B16;		/* unused */
} xPrintGetAttributesReq;
#define sz_xPrintGetAttributesReq	12

typedef struct {
	BYTE	type;			/* X_Reply */
	CARD8	unused;			/* not used */
	CARD16	sequenceNumber B16;
	CARD32	length B32;
	CARD32	stringLen B32;		/* length of xrm db string */
	CARD32	pad1 B32;
	CARD32	pad2 B32;
	CARD32	pad3 B32;
	CARD32	pad4 B32;
	CARD32	pad5 B32;

        /* variable portion *****************************************
	STRING8	string;                  * xrm db as a string *
	BYTE	pad(stringLen)           * unused *
        ************************************************************/
} xPrintGetAttributesReply;
#define sz_xPrintGetAttributesReply	32


typedef struct _PrintSetAttributes {
        CARD8   reqType;        	/* always PrintReqCode */
	CARD8   printReqType;		/* always X_PrintSetAttributes */
	CARD16	length B16;
	PCONTEXT printContext B32;	/* print context */
	CARD32	stringLen B32;		/* length of xrm db string */
        CARD8   type;                   /* type */
	CARD8   rule;			/* replacement rule */
	CARD16  pad1 B16;		/* unused */

        /* variable portion *****************************************
	STRING8	string;                  * xrm db as a string *
	BYTE	pad(stringLen)           * unused *
        ************************************************************/
} xPrintSetAttributesReq;
#define sz_xPrintSetAttributesReq	16


typedef struct _PrintGetOneAttribute {
        CARD8   reqType;        	/* always PrintReqCode */
	CARD8   printReqType;		/* always X_PrintGetOneAttribute */
	CARD16	length B16;
	PCONTEXT printContext B32;	/* print context */
	CARD32	nameLen;		/* length of name string */
        CARD8   type;			/* type */
        CARD8   pad1;			/* unused */
        CARD16  pad2 B16;		/* unused */

        /* variable portion *****************************************
	STRING8	name;			 * name as a string *
	BYTE	pad(name)		 * unused *
        ************************************************************/
} xPrintGetOneAttributeReq;
#define sz_xPrintGetOneAttributeReq	16

typedef struct {
	BYTE	type;			/* X_Reply */
	CARD8	unused;			/* not used */
	CARD16	sequenceNumber B16;
	CARD32	length B32;
	CARD32	valueLen B32;		/* length of value string */
	CARD32	pad1 B32;
	CARD32	pad2 B32;
	CARD32	pad3 B32;
	CARD32	pad4 B32;
	CARD32	pad5 B32;

        /* variable portion *****************************************
	STRING8	value;			 * value as a string *
	BYTE	pad(value)		 * unused *
        ************************************************************/
} xPrintGetOneAttributeReply;
#define sz_xPrintGetOneAttributeReply	32


typedef struct _PrintGetPageDimensions {
	CARD8	reqType;		/* always PrintReqCode */
	CARD8	printReqType;		/* always X_PrintGetPageDimensions */
	CARD16	length B16;
	PCONTEXT printContext B32;	/* print context */
} xPrintGetPageDimensionsReq;		
#define sz_xPrintGetPageDimensionsReq	8

typedef struct {
	BYTE	type;			/* X_Reply */
	CARD8	unused;			/* not used */
	CARD16	sequenceNumber B16;
	CARD32	length B32;
	CARD16	width;			/* total pixel width */
	CARD16	height;			/* total pixel height */
	CARD16	rx;			/* reproducable x pixel offset */
	CARD16	ry;			/* reproducable y pixel offset */
	CARD16	rwidth;			/* reproducable x pixel width */
	CARD16	rheight;		/* reproducable y pixel width */
	CARD32	pad1 B32;
	CARD32	pad2 B32;
	CARD32	pad3 B32;
} xPrintGetPageDimensionsReply;
#define sz_xPrintGetPageDimensionsReply	32


typedef struct _PrintQueryScreens {
	CARD8	reqType;		/* always PrintReqCode */
	CARD8	printReqType;		/* always X_PrintQueryScreens */
	CARD16	length B16;
} xPrintQueryScreensReq;		
#define sz_xPrintQueryScreensReq	4

typedef struct {
	BYTE	type;			/* X_Reply */
	CARD8	unused;			/* not used */
	CARD16	sequenceNumber B16;
	CARD32	length B32;
	CARD32	listCount;		/* number of screens following */
	CARD32	pad1 B32;
	CARD32	pad2 B32;
	CARD32	pad3 B32;
	CARD32	pad4 B32;
	CARD32	pad5 B32;

        /* variable portion *****************************************
	WINDOW	rootWindow;		 * root window of screen *
        ************************************************************/
} xPrintQueryScreensReply;
#define sz_xPrintQueryScreensReply	32

typedef struct _PrintSetImageResolution {
	CARD8	reqType;		/* always PrintReqCode */
	CARD8	printReqType;		/* always X_PrintSetImageResolution */
	CARD16	length B16;
	PCONTEXT printContext B32;	/* print context */
	CARD16 imageRes B16;		/* image resolution */
	CARD16 pad1 B16;
} xPrintSetImageResolutionReq;
#define sz_xPrintSetImageResolutionReq	12

typedef struct {
	BYTE	type;			/* X_Reply */
	BOOL	status;			/* accepted or not */
	CARD16	sequenceNumber B16;
	CARD32	length B32;
	CARD16	prevRes B16;		/* previous resolution */
	CARD16	pad1 B32;
	CARD32	pad2 B32;
	CARD32	pad3 B32;
	CARD32	pad4 B32;
	CARD32	pad5 B32;
	CARD32	pad6 B32;
} xPrintSetImageResolutionReply;
#define sz_xPrintSetImageResolutionReply 32

typedef struct _PrintGetImageResolution {
	CARD8	reqType;		/* always PrintReqCode */
	CARD8	printReqType;		/* always X_PrintGetImageResolution */
	CARD16	length B16;
	PCONTEXT printContext B32;	/* print context */
} xPrintGetImageResolutionReq;
#define sz_xPrintGetImageResolutionReq	8

typedef struct {
	BYTE	type;			/* X_Reply */
	CARD8	unused;
	CARD16	sequenceNumber B16;
	CARD32	length B32;
	CARD16	imageRes B16;		/* image resolution */
	CARD16	pad1 B32;
	CARD32	pad2 B32;
	CARD32	pad3 B32;
	CARD32	pad4 B32;
	CARD32	pad5 B32;
	CARD32	pad6 B32;
} xPrintGetImageResolutionReply;
#define sz_xPrintGetImageResolutionReply 32

#ifndef _XP_PRINT_SERVER_
/***********************************************************************
 *
 * Library-only definitions.
 */
extern XPHinterProc  _xp_hinter_proc;
extern char         *_xp_hinter_desc;
extern int           _xp_hinter_init;

#endif /* _XP_PRINT_SERVER_ */

#ifdef _XP_PRINT_SERVER_
/***********************************************************************
 *
 * Server-only definitions shared between the extension and DDX layers.
 *
 */
 
/*
 * Internal return code used to indicate that the requesting
 * client has been suspended.
 */
#define Suspended 84

extern void XpRegisterPrinterScreen(
    ScreenPtr pScreen,
    int (*CreateContext)());

typedef struct _xpprintFuncs {
    int (*StartJob)(); /* pContext, client */
    int (*EndJob)(); /* pContext, client */
    int (*StartDoc)(); /* pContext, client */
    int (*EndDoc)(); /* pContext, client */
    int (*StartPage)(); /* pContext, pWin, client, exposures */
    int (*EndPage)(); /* pContext, client */
    int (*PutDocumentData)(); /* pContext,pDraw,pData,len_data,pFmt,len_fmt,pOpt,len_opt, client */
    int (*GetDocumentData)(); /* pContext,pData,len_data,pFmt,len_fmt,pOpt,len_opt, client */
    int (*DestroyContext)(); /* pContext, client */
    char *(*GetAttributes)(); /* pContext, pool */
    char *(*GetOneAttribute)(); /* pContext, pool, attr */
    int (*SetAttributes)(); /* pContext, pool, attrs */
    int (*AugmentAttributes)(); /* pContext, pool, attrs */
    int (*GetMediumDimensions)(); /* pPrintContext, pWidth, pHeight */
    int (*GetReproducibleArea)(); /* pPrintContext, pRect */
    int (*SetImageResolution)(); /* pPrintContext, imageRes, pStatus */
} XpDriverFuncs, *XpDriverFuncsPtr;

/*
 * Each print context is represented by one of the following structs
 * associated with a resource ID of type RTcontext .  A pointer to
 * the context is placed in the Xp extension's devPrivates
 * element in each client * which establishes a context via
 * either initContext or setContext.
 * The context pointer is also placed in the struct indicated by the
 * RTpage resource associated with each StartPage'd window.
 */
typedef struct _XpContext {
        XID contextID;
        char *printerName;
        int screenNum;          /* screen containing the printer */
        struct _XpClient *clientHead; /* list of clients */
        CARD32 state;
        VisualID pageWin;
        DevUnion *devPrivates;
        XpDriverFuncs funcs;
	ClientPtr clientSlept;
	int imageRes;
} XpContextRec, *XpContextPtr;

extern XpContextPtr XpGetPrintContext(
    ClientPtr client);

#endif /* _XP_PRINT_SERVER_ */

_XFUNCPROTOEND

#endif /* _XpPrintstr_H_ */

